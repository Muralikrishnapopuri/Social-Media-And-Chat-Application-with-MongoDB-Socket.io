import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { HelmetProvider, Helmet } from 'react-helmet-async';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import JoinChat from './pages/JoinChat';
import Live from './pages/Live';
import Profile from './components/Profile';
import NewFriends from './components/NewFriends';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const user = JSON.parse(localStorage.getItem('zestchat-user') || '{}');
        const token = user.token;
        const username = user.username;

        if (!token || !username) {
          setIsAuthenticated(false);
          setIsLoading(false);
          return;
        }

        // Verify token with backend using explicit base URL
        const response = await fetch('http://localhost:5000/api/auth/verify-token', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        });

        if (response.ok) {
          const data = await response.json();
          if (data.success) {
            // Update localStorage with new token if provided
            localStorage.setItem('zestchat-user', JSON.stringify({
              ...user,
              token: data.token || token
            }));
            setIsAuthenticated(true);
          } else {
            setIsAuthenticated(false);
            localStorage.removeItem('zestchat-user');
          }
        } else {
          setIsAuthenticated(false);
          localStorage.removeItem('zestchat-user');
        }
      } catch (error) {
        console.error('Auth check failed:', error);
        setIsAuthenticated(false);
        localStorage.removeItem('zestchat-user');
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  if (isLoading) {
    return null; // Changed from Loading... text to null to avoid rendering anything during loading
  }

  return isAuthenticated ? children : <Navigate to="/" replace />;
};

function Layout() {
  const location = useLocation();
  const isLiveRoute = location.pathname === '/live/' || location.pathname.startsWith('/live');

  const getPageMeta = () => {
    switch (location.pathname) {
      case '/':
        return {
          title: 'Live Chat - ZestChat | Top Alternative to Discord, Slack, WhatsApp & More',
          description: 'Explore ZestChat, a real-time live chat app that beats Discord, Slack, WhatsApp, Telegram, and Zoom with seamless messaging and unique features.',
          keywords: 'ZestChat, live chat, Discord alternative, Slack competitor, WhatsApp rival, Telegram substitute, Zoom alternative, real-time messaging',
          content: (
            <div>
              <p>
                Tired of Discord’s complexity, Slack’s pricing, WhatsApp’s privacy issues, Telegram’s interface, or Zoom’s video-only focus? ZestChat offers a fresh, fast, and free live chat alternative to these trending platforms. Enjoy real-time messaging that rivals Microsoft Teams too!
              </p>
              <p>
                Whether you’re switching from Discord, Slack, WhatsApp, Telegram, Zoom, or Microsoft Teams, ZestChat delivers a better live chat experience for personal and team communication.
              </p>
            </div>
          ),
        };
      case '/about':
        return {
          title: 'About Live Chat - ZestChat | Outshining Telegram, Slack & Microsoft Teams',
          description: 'Learn about ZestChat, a live chat app built to outpace Telegram, Slack, Microsoft Teams, and other trending platforms with superior speed and simplicity.',
          keywords: 'ZestChat about, live chat, Telegram alternative, Slack rival, Microsoft Teams competitor, messaging platform',
          content: (
            <div>
              <p>
                ZestChat was created to surpass trending platforms like Telegram, Slack, and Microsoft Teams. Unlike WhatsApp’s limited group features or Zoom’s video focus, we prioritize real-time live chat with a user-friendly design that Discord users will love.
              </p>
            </div>
          ),
        };
      case '/join-chat':
        return {
          title: 'Join Live Chat - ZestChat | Better Than Discord, WhatsApp & Zoom',
          description: 'Join chat rooms instantly with ZestChat, a leading live chat alternative to Discord, WhatsApp, Zoom, and Telegram for real-time conversations.',
          keywords: 'ZestChat join, live chat, Discord substitute, WhatsApp alternative, Zoom rival, Telegram competitor, chat rooms',
          content: (
            <div>
              <p>
                Ready to ditch Discord’s cluttered servers, WhatsApp’s basic groups, or Zoom’s meeting fatigue? Join ZestChat’s live chat rooms for a seamless experience that beats Telegram and Slack too. Start chatting now and see why we’re the top alternative!
              </p>
            </div>
          ),
        };
      case '/live':
        return {
          title: 'Live Chat - ZestChat | Outperforming Slack, Telegram & Microsoft Teams',
          description: 'Experience ZestChat’s live chat that outperforms Slack, Telegram, Microsoft Teams, and Zoom with real-time speed and engagement.',
          keywords: 'ZestChat live chat, Slack alternative, Telegram rival, Microsoft Teams substitute, Zoom competitor, real-time chat',
          content: (
            <div>
              <p>
                Go live with ZestChat, a chat app that leaves Slack’s channels, Telegram’s delays, Microsoft Teams’ complexity, and Zoom’s video focus in the dust. Unlike WhatsApp or Discord, our live chat is built for instant, engaging conversations.
              </p>
            </div>
          ),
        };
      default:
        if (location.pathname.startsWith('/live/group')) { // Fixed from /live/* to /live/group
          return {
            title: 'Group Chat - ZestChat | Real-Time Messaging',
            description: 'Join a ZestChat group for real-time messaging that beats Discord, Slack, and WhatsApp.',
            keywords: 'ZestChat group chat, live chat, real-time messaging, Discord alternative, Slack rival',
            content: <div><p>Chat live in ZestChat groups with seamless performance.</p></div>,
          };
        }
        return {
          title: 'Live Chat - ZestChat | Outranking Discord, Slack, WhatsApp & More',
          description: 'ZestChat, a real-time live chat app designed to outrank trending platforms like Discord, Slack, WhatsApp, Telegram, Zoom, and Microsoft Teams.',
          keywords: 'ZestChat, live chat, Discord, Slack, WhatsApp, Telegram, Zoom, Microsoft Teams, alternative',
          content: (
            <div>
              <p>
                Chat smarter with ZestChat, an app that tops Discord, Slack, WhatsApp, Telegram, Zoom, and Microsoft Teams. Our live chat platform combines the best of these trending sites into one powerful, free solution.
              </p>
            </div>
          ),
        };
    }
  };

  const { title, description, keywords, content } = getPageMeta();

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <meta name="keywords" content={keywords} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={`https://zestchat.com${location.pathname}`} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://zestchat.com/og-image.jpg" />
        <script type="application/ld+json">{`
          {
            "@context": "https://schema.org",
            "@type": "WebApplication",
            "name": "Live Chat - ZestChat",
            "description": "${description}",
            "url": "https://zestchat.com${location.pathname}",
            "applicationCategory": "Communication",
            "operatingSystem": "Web",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "sameAs": [
              "https://discord.com",
              "https://slack.com",
              "https://whatsapp.com",
              "https://telegram.org",
              "https://zoom.us",
              "https://teams.microsoft.com"
            ],
            "aggregateRating": {
              "@type": "AggregateRating",
              "ratingValue": "4.8",
              "reviewCount": "150"
            }
          }
        `}</script>
      </Helmet>
      {!isLiveRoute && <Navbar />}
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home extraContent={content} />} />
          <Route
            path="/about"
            element={
              <div className="p-20 text-center text-gray-800 text-xl">
                {content}
                <br />
                About Page (Coming Soon)
              </div>
            }
          />
          <Route path="/join-chat" element={<JoinChat extraContent={content} />} />
          <Route path="/live/newfriends" element={<NewFriends extraContent={content} />} />

          <Route path="/live/profile/:username" element={<Profile />} />
          <Route
            path="/live/*"
            element={
              <ProtectedRoute>
                <Live extraContent={content} />
              </ProtectedRoute>
            }
          />
        </Routes>
      </main>
      {!isLiveRoute && <Footer />}
    </div>
  );
};

function App() {
  return (
    <HelmetProvider>
      <Router>
        <Layout />
      </Router>
    </HelmetProvider>
  );
}

export default App;