import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useParams, useLocation, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Menu,
  UserMinus,
  Users,
  Share2,
  Info,
  Smile,
  Send,
  X,
  MoreVertical,
  Star,
  Circle,
  Triangle,
  User,
  MessageSquare,
  Shield,
  UserX,
  Slash,
  Gift,
  FileText,
  Home,
  ShoppingBag,
  Heart,
  Settings as SettingsIcon,
} from "react-feather";
import EmojiPicker from "emoji-picker-react";
import axios from "axios";
import Profile from "./Profile";

const GroupChat = ({ activeSection, handleSectionChange }) => {
  const { groupId } = useParams();
  const { state } = useLocation();
  const navigate = useNavigate();
  const { groupTitle = "Group Chat", groupPic = null, reset = false } = state || {};

  const [isMenuOpen, setIsMenuOpen] = useState(reset ? false : false);
  const [message, setMessage] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(reset ? false : false);
  const [groupData, setGroupData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showMembers, setShowMembers] = useState(reset ? false : false);
  const [memberProfiles, setMemberProfiles] = useState([]);
  const [membersLoading, setMembersLoading] = useState(false);
  const [selectedUserMenu, setSelectedUserMenu] = useState(null);
  const [showAboutGroup, setShowAboutGroup] = useState(reset ? false : false);
  const [showProfile, setShowProfile] = useState(reset ? false : false);
  const [profileUsername, setProfileUsername] = useState(null);

  const isDarkTheme = localStorage.getItem("zestchat-theme") === "dark";
  const userData = useMemo(() => JSON.parse(localStorage.getItem("zestchat-user")), []);
  const token = userData?.token;
  const currentUser = userData?.username;
  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

  const axiosInstance = useMemo(
    () =>
      axios.create({
        baseURL: API_URL,
        headers: { Authorization: `Bearer ${token}` },
      }),
    [API_URL, token]
  );

  // Sidebar-related logic
  const themes = useMemo(() => ({
    light: {
      sidebar: 'bg-gradient-to-b from-gray-50 to-gray-100',
      content: 'bg-gradient-to-br from-gray-100 via-gray-200 to-gray-300',
      text: 'text-black-100',
      hover: 'hover:bg-opacity-30 hover:bg-sky-900',
      active: 'bg-gradient-to-l from-red-500 to-pink-500',
      highlight: 'bg-gradient-to-l from-purple-500 to-indigo-500'
    },
    dark: {
      sidebar: 'bg-gradient-to-b from-gray-900 to-black',
      content: 'bg-gradient-to-br from-gray-700 via-gray-800 to-gray-900',
      text: 'text-white',
      hover: 'hover:bg-opacity-10 hover:bg-sky-100',
      active: 'bg-gradient-to-l from-red-500 to-pink-500',
      highlight: 'bg-gradient-to-l from-purple-600 to-indigo-600'
    }
  }), []);

  const currentTheme = isDarkTheme ? themes.dark : themes.light;

  const mobileBottomItems = useMemo(() => [
    { id: 'home', icon: Home, label: 'Home', route: '/live' },
    { id: 'chat', icon: MessageSquare, label: 'Chat', route: '/live/chat' },
    { id: 'newfriends', icon: Heart, label: 'New Friends', route: '/live/newfriends', isHighlight: true },
    { id: 'store', icon: ShoppingBag, label: 'Store', route: '/live/store' },
    { id: 'settings', icon: SettingsIcon, label: 'Settings', route: '/live/settings' },
  ], []);

  const mobileNavItemClass = (isActive, isHighlight) => `
    relative p-3 flex flex-col items-center cursor-pointer
    transition-all duration-300
    ${currentTheme.text}
    ${isHighlight ? 'hover:scale-125 hover:shadow-xl' : currentTheme.hover}
    ${isActive ? (isHighlight ? `${currentTheme.highlight} text-white scale-125` : `${currentTheme.active} text-white`) : 'hover:scale-110'}
  `;

  const fetchGroupDetails = useCallback(async () => {
    try {
      const response = await axiosInstance.get(`/api/groups/${groupId}`);
      setGroupData(response.data.group);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to fetch group details");
      if (err.response?.status === 401) {
        localStorage.removeItem("zestchat-user");
        navigate("/join-chat");
      }
    }
  }, [groupId, axiosInstance, navigate]);

  const fetchMemberProfiles = useCallback(
    async (usernames, blocklist = []) => {
      try {
        setMembersLoading(true);
        const allUsernames = [...new Set([...usernames, ...blocklist])];
        const response = await axiosInstance.post("/api/groups/user-profiles", {
          user_list: allUsernames,
        });
        setMemberProfiles(response.data.users);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to fetch member profiles");
      } finally {
        setMembersLoading(false);
      }
    },
    [axiosInstance]
  );

  const handleLeaveGroup = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await axiosInstance.post(`/api/groups/leave/${groupId}`);
      console.log(response.data.message);
      setIsMenuOpen(false);
      navigate("/live");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to leave group");
      if (err.response?.status === 401) {
        localStorage.removeItem("zestchat-user");
        navigate("/join-chat");
      }
    } finally {
      setLoading(false);
    }
  }, [groupId, axiosInstance, navigate]);

  const handleShowMembers = useCallback(async () => {
    setShowMembers(true);
    setIsMenuOpen(false);
    setShowAboutGroup(false);
    if (groupData?.users_array) {
      await fetchMemberProfiles(groupData.users_array, groupData.blocklist);
    }
  }, [groupData, fetchMemberProfiles]);

  const handleCloseMembers = useCallback(() => {
    setShowMembers(false);
    setMemberProfiles([]);
    setMembersLoading(false);
    setSelectedUserMenu(null);
  }, []);

  const toggleUserMenu = useCallback((username) => {
    setSelectedUserMenu((prev) => (prev === username ? null : username));
  }, []);

  const handleViewProfile = useCallback(
    (username) => {
      setProfileUsername(username);
      setShowProfile(true);
      setSelectedUserMenu(null);
    },
    []
  );

  const handleMakeAdmin = useCallback(
    async (username) => {
      setLoading(true);
      setError("");
      try {
        const response = await axiosInstance.post(`/api/groups/make-admin/${groupId}`, { username });
        setGroupData(response.data.group);
        setSelectedUserMenu(null);
        await fetchMemberProfiles(response.data.group.users_array, response.data.group.blocklist);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to make user admin");
        if (err.response?.status === 401) {
          localStorage.removeItem("zestchat-user");
          navigate("/join-chat");
        }
      } finally {
        setLoading(false);
      }
    },
    [groupId, axiosInstance, navigate, fetchMemberProfiles]
  );

  const handleRemoveAdmin = useCallback(
    async (username) => {
      setLoading(true);
      setError("");
      try {
        const response = await axiosInstance.post(`/api/groups/remove-admin/${groupId}`, { username });
        setGroupData(response.data.group);
        setSelectedUserMenu(null);
        await fetchMemberProfiles(response.data.group.users_array, response.data.group.blocklist);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to remove user as admin");
        if (err.response?.status === 401) {
          localStorage.removeItem("zestchat-user");
          navigate("/join-chat");
        }
      } finally {
        setLoading(false);
      }
    },
    [groupId, axiosInstance, navigate, fetchMemberProfiles]
  );

  const handleRemoveUser = useCallback(
    async (username) => {
      setLoading(true);
      setError("");
      try {
        const response = await axiosInstance.post(`/api/groups/remove-user/${groupId}`, { username });
        setGroupData(response.data.group);
        setSelectedUserMenu(null);
        await fetchMemberProfiles(response.data.group.users_array, response.data.group.blocklist);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to remove user");
        if (err.response?.status === 401) {
          localStorage.removeItem("zestchat-user");
          navigate("/join-chat");
        }
      } finally {
        setLoading(false);
      }
    },
    [groupId, axiosInstance, navigate, fetchMemberProfiles]
  );

  const handleBanUser = useCallback(
    async (username) => {
      setLoading(true);
      setError("");
      try {
        const response = await axiosInstance.post(`/api/groups/ban-user/${groupId}`, { username });
        console.log(`Ban user response: ${response.data.message}`);
        setGroupData(response.data.group);
        setSelectedUserMenu(null);
        await fetchMemberProfiles(response.data.group.users_array, response.data.group.blocklist);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to ban user");
        if (err.response?.status === 401) {
          localStorage.removeItem("zestchat-user");
          navigate("/join-chat");
        }
      } finally {
        setLoading(false);
      }
    },
    [groupId, axiosInstance, navigate, fetchMemberProfiles]
  );

  const handleApproveUser = useCallback(
    async (username) => {
      setLoading(true);
      setError("");
      try {
        const response = await axiosInstance.post(`/api/groups/approve-user/${groupId}`, { username });
        setGroupData(response.data.group);
        setSelectedUserMenu(null);
        await fetchMemberProfiles(response.data.group.users_array, response.data.group.blocklist);
      } catch (err) {
        setError(err.response?.data?.message || "Failed to approve user");
        if (err.response?.status === 401) {
          localStorage.removeItem("zestchat-user");
          navigate("/join-chat");
        }
      } finally {
        setLoading(false);
      }
    },
    [groupId, axiosInstance, navigate, fetchMemberProfiles]
  );

  const handleShowAboutGroup = useCallback(() => {
    setShowAboutGroup(true);
    setIsMenuOpen(false);
    setShowMembers(false);
  }, []);

  const handleCloseAboutGroup = useCallback(() => {
    setShowAboutGroup(false);
  }, []);

  useEffect(() => {
    if (token) {
      fetchGroupDetails();
    } else {
      navigate("/join-chat");
    }
  }, [token, fetchGroupDetails, navigate]);

  useEffect(() => {
    setIsMenuOpen(false);
    setMessage("");
    setShowEmojiPicker(false);
    setGroupData(null);
    setError("");
    setLoading(false);
    setShowMembers(false);
    setMemberProfiles([]);
    setMembersLoading(false);
    setSelectedUserMenu(null);
    setShowAboutGroup(false);
    setShowProfile(false);
    setProfileUsername(null);
  }, [groupId]);

  const handleEmojiClick = useCallback((emojiObject) => {
    setMessage((prev) => prev + emojiObject.emoji);
    setShowEmojiPicker(false);
  }, []);

  const handleSendMessage = useCallback(() => {
    if (message.trim()) {
      console.log(`Sending message to group ${groupId}: ${message}`);
      setMessage("");
    }
  }, [message, groupId]);

  const handleBack = useCallback(() => {
    if (showAboutGroup || showMembers) {
      setShowAboutGroup(false);
      setShowMembers(false);
    } else {
      navigate("/live");
    }
  }, [navigate, showAboutGroup, showMembers]);

  const isOwnerOrAdmin = useMemo(
    () => groupData?.owner === currentUser || (groupData?.admins && groupData.admins.includes(currentUser)),
    [groupData, currentUser]
  );

  const formattedBirthday = useMemo(() => {
    if (groupData?.created_at) {
      return new Date(groupData.created_at).toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      });
    }
    return "N/A";
  }, [groupData?.created_at]);

  const handleProfileBack = useCallback(() => {
    setShowProfile(false);
    setProfileUsername(null);
  }, []);

  if (showProfile) {
    return (
      <Profile 
        username={profileUsername} 
        onBack={handleProfileBack} 
        activeSection={activeSection}
        handleSectionChange={handleSectionChange}
      />
    );
  }

  if (!groupData && !error) {
    return (
      <div className={`flex h-screen items-center justify-center ${isDarkTheme ? "bg-gray-900" : "bg-gray-100"}`}>
        <div className="flex space-x-2">
          <div
            className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? "bg-blue-400" : "bg-blue-600"}`}
            style={{ animationDelay: "0s" }}
          ></div>
          <div
            className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? "bg-blue-400" : "bg-blue-600"}`}
            style={{ animationDelay: "0.2s" }}
          ></div>
          <div
            className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? "bg-blue-400" : "bg-blue-600"}`}
            style={{ animationDelay: "0.4s" }}
          ></div>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex flex-col h-screen ${isDarkTheme ? "bg-gray-900" : "bg-gray-100"}`}>
      {!showAboutGroup && !showMembers && (
        <div className={`flex items-center justify-between p-4 ${isDarkTheme ? "bg-gray-800" : "bg-white"} shadow-md`}>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleBack}
              className={`${isDarkTheme ? "text-gray-300" : "text-gray-700"} hover:text-blue-500`}
            >
              <ArrowLeft size={24} />
            </button>
            {groupPic ? (
              <img src={groupPic} alt={groupTitle} className="w-10 h-10 rounded-full object-cover" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-gray-500 flex items-center justify-center">
                <Users size={24} className="text-white" />
              </div>
            )}
            <h2 className={`text-lg font-semibold ${isDarkTheme ? "text-gray-100" : "text-gray-800"}`}>
              {groupTitle}
            </h2>
          </div>
          <button
            onClick={() => setIsMenuOpen((prev) => !prev)}
            className={`${isDarkTheme ? "text-gray-300" : "text-gray-700"} hover:text-blue-500`}
          >
            <Menu size={24} />
          </button>
        </div>
      )}

      {isMenuOpen && (
        <div
          className={`absolute top-16 right-4 w-48 ${
            isDarkTheme ? "bg-gray-800" : "bg-white"
          } rounded-lg shadow-lg z-50`}
        >
          {currentUser !== groupData?.owner && (
            <button
              onClick={handleLeaveGroup}
              className={`w-full flex items-center p-2 ${
                isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
              } ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
              disabled={loading}
            >
              <UserMinus size={18} className="mr-2" /> Leave Group
            </button>
          )}
          <button
            onClick={handleShowMembers}
            className={`w-full flex items-center p-2 ${
              isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
            }`}
          >
            <Users size={18} className="mr-2" /> Group Members
          </button>
          <button
            className={`w-full flex items-center p-2 ${
              isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
            }`}
          >
            <Share2 size={18} className="mr-2" /> Share Group
          </button>
          <button
            onClick={handleShowAboutGroup}
            className={`w-full flex items-center p-2 ${
              isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
            }`}
          >
            <Info size={18} className="mr-2" /> About Group
          </button>
        </div>
      )}

      {showMembers && groupData && (
        <div className={`h-screen flex flex-col ${isDarkTheme ? "bg-gray-800" : "bg-white"} shadow-md`}>
          <div className="flex justify-between items-center p-4">
            <button
              onClick={handleBack}
              className={`${isDarkTheme ? "text-gray-300" : "text-gray-700"} hover:text-blue-500`}
            >
              <ArrowLeft size={24} />
            </button>
            <h3 className={`text-lg font-semibold ${isDarkTheme ? "text-gray-100" : "text-gray-800"}`}>
              Group Members ({groupData.total_users})
            </h3>
            <div className="w-6"></div>
          </div>
          {membersLoading ? (
            <div className="flex justify-center items-center flex-1">
              <div className="flex space-x-2">
                <div
                  className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? "bg-blue-400" : "bg-blue-600"}`}
                  style={{ animationDelay: "0s" }}
                ></div>
                <div
                  className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? "bg-blue-400" : "bg-blue-600"}`}
                  style={{ animationDelay: "0.2s" }}
                ></div>
                <div
                  className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? "bg-blue-400" : "bg-blue-600"}`}
                  style={{ animationDelay: "0.4s" }}
                ></div>
              </div>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto scrollbar-hidden p-4">
              <ul className="space-y-2">
                {memberProfiles.map((user) => (
                  <li
                    key={user.username}
                    className={`flex items-center justify-between p-2 rounded-lg ${
                      isDarkTheme ? "bg-gray-700 text-gray-100" : "bg-gray-200 text-gray-800"
                    } relative ${groupData.blocklist.includes(user.username) ? "opacity-50 z-10" : "z-3"}`}
                  >
                    <div className="flex items-center">
                      {user.profile_pic ? (
                        <img
                          src={`${API_URL}${user.profile_pic}`}
                          alt={user.username}
                          className={`w-8 h-8 rounded-full object-cover mr-2 border-2 ${
                            user.gender === "Male"
                              ? "border-blue-300"
                              : user.gender === "Female"
                              ? "border-pink-300"
                              : user.gender === "Other"
                              ? "border-red-300"
                              : "border-gray-300"
                          }`}
                          loading="lazy"
                        />
                      ) : (
                        <div
                          className={`w-8 h-8 rounded-full bg-gray-500 flex items-center justify-center mr-2 border-2 ${
                            user.gender === "Male"
                              ? "border-blue-300"
                              : user.gender === "Female"
                              ? "border-pink-300"
                              : user.gender === "Other"
                              ? "border-red-300"
                              : "border-gray-300"
                          }`}
                        >
                          <Users size={16} className="text-white" />
                        </div>
                      )}
                      <div>
                        <span className="font-medium">{user.username}</span>
                        {user.username === groupData.owner ? (
                          <span className="text-sm text-blue-500 ml-1">(Owner)</span>
                        ) : groupData.admins.includes(user.username) ? (
                          <span className="text-sm text-green-500 ml-1">(Admin)</span>
                        ) : groupData.blocklist.includes(user.username) ? (
                          <span className="text-sm text-red-500 ml-1">(Banned)</span>
                        ) : null}
                        <div className="text-sm text-gray-400">
                          Age: {user.age || "N/A"} | {user.gender || "N/A"}
                        </div>
                      </div>
                    </div>
                    <div className="relative">
                      {user.username !== currentUser && (
                        <>
                          <button
                            onClick={() => toggleUserMenu(user.username)}
                            className="text-gray-400 hover:text-gray-600"
                          >
                            <MoreVertical size={16} />
                          </button>
                          {selectedUserMenu === user.username && (
                            <div
                              className={`absolute right-0 top-full mt-2 w-48 ${
                                isDarkTheme ? "bg-gray-800" : "bg-white"
                              } rounded-lg shadow-lg z-20`}
                            >
                              <button
                                onClick={() => handleViewProfile(user.username)}
                                className={`w-full flex items-center p-2 ${
                                  isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
                                }`}
                              >
                                <User size={16} className="mr-2" /> View Profile
                              </button>
                              <button
                                className={`w-full flex items-center p-2 ${
                                  isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
                                }`}
                              >
                                <MessageSquare size={16} className="mr-2" /> Private Message
                              </button>
                              {isOwnerOrAdmin && user.username !== groupData.owner && (
                                <>
                                  {!groupData.admins.includes(user.username) ? (
                                    <button
                                      onClick={() => handleMakeAdmin(user.username)}
                                      className={`w-full flex items-center p-2 ${
                                        isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
                                      } ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
                                      disabled={loading}
                                    >
                                      <Shield size={16} className="mr-2" /> Make as Admin
                                    </button>
                                  ) : (
                                    <button
                                      onClick={() => handleRemoveAdmin(user.username)}
                                      className={`w-full flex items-center p-2 ${
                                        isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
                                      } ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
                                      disabled={loading}
                                    >
                                      <Shield size={16} className="mr-2" /> Remove as Admin
                                    </button>
                                  )}
                                  <button
                                    onClick={() => handleRemoveUser(user.username)}
                                    className={`w-full flex items-center p-2 ${
                                      isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
                                      } ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
                                    disabled={loading}
                                  >
                                    <UserX size={16} className="mr-2" /> Remove
                                  </button>
                                  {!groupData.blocklist.includes(user.username) ? (
                                    <button
                                      onClick={() => handleBanUser(user.username)}
                                      className={`w-full flex items-center p-2 ${
                                        isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
                                      } ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
                                      disabled={loading}
                                    >
                                      <Slash size={16} className="mr-2" /> Ban User
                                    </button>
                                  ) : (
                                    <button
                                      onClick={() => handleApproveUser(user.username)}
                                      className={`w-full flex items-center p-2 ${
                                        isDarkTheme ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-200"
                                      } ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
                                      disabled={loading}
                                    >
                                      <Shield size={16} className="mr-2" /> Approve User
                                    </button>
                                  )}
                                </>
                              )}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {showAboutGroup && groupData && (
        <div className={`h-screen flex flex-col ${isDarkTheme ? "bg-gray-900" : "bg-gray-100"}`}>
          <div className={`flex justify-between items-center p-4 ${isDarkTheme ? "bg-gray-800" : "bg-white"} shadow-md`}>
            <button
              onClick={handleBack}
              className={`${isDarkTheme ? "text-gray-300" : "text-gray-700"} hover:text-blue-500`}
            >
              <ArrowLeft size={24} />
            </button>
            <h3 className={`text-lg font-semibold ${isDarkTheme ? "text-gray-100" : "text-gray-800"}`}>
              About {groupData.group_title}
            </h3>
            <div className="w-6"></div>
          </div>
          <div className="flex-1 overflow-y-auto scrollbar-hidden p-4">
            <div
              className={`w-full max-w-md mx-auto p-6 rounded-xl shadow-lg transform hover:scale-105 transition-transform duration-300 ${
                isDarkTheme ? "bg-gray-800 text-gray-100" : "bg-white text-gray-800"
              } border ${isDarkTheme ? "border-gray-700" : "border-gray-200"}`}
            >
              <div className="flex justify-center mb-6">
                {groupData.group_pic ? (
                  <img
                    src={groupData.group_pic}
                    alt={groupData.group_title}
                    className="w-20 h-20 rounded-full object-cover border-4 border-blue-500 shadow-md"
                    loading="lazy"
                  />
                ) : (
                  <div
                    className={`w-20 h-20 rounded-full flex items-center justify-center border-4 border-blue-500 shadow-md ${
                      isDarkTheme ? "bg-gray-600" : "bg-gray-300"
                    }`}
                  >
                    <Users size={36} className={isDarkTheme ? "text-gray-300" : "text-gray-600"} />
                  </div>
                )}
              </div>
              <h2 className="text-xl font-bold text-center mb-4">{groupData.group_title}</h2>
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Users size={18} className="text-green-500" />
                  <span className="text-sm">
                    <span className="font-semibold">Members:</span> {groupData.total_users}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <User size={18} className="text-purple-500" />
                  <span className="text-sm">
                    <span className="font-semibold">Owner:</span> {groupData.owner}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Gift size={18} className="text-pink-500" />
                  <span className="text-sm">
                    <span className="font-semibold">Created:</span> {formattedBirthday}
                  </span>
                </div>
                <div className="flex items-start space-x-2">
                  <FileText size={18} className="text-yellow-500" />
                  <div className="text-sm">
                    <span className="font-semibold">Description:</span>
                    <p className={isDarkTheme ? "text-gray-300" : "text-gray-700"}>
                      {groupData.description || "No description available"}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {error && <div className="p-4 text-red-500 text-center">{error}</div>}

      {loading && (
        <div className="fixed inset-0 flex justify-center items-center z-[1000] bg-black bg-opacity-50">
          <div className="flex space-x-2">
            <div
              className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? "bg-blue-400" : "bg-blue-600"}`}
              style={{ animationDelay: "0s" }}
            ></div>
            <div
              className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? "bg-blue-400" : "bg-blue-600"}`}
              style={{ animationDelay: "0.2s" }}
            ></div>
            <div
              className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? "bg-blue-400" : "bg-blue-600"}`}
              style={{ animationDelay: "0.4s" }}
            ></div>
          </div>
        </div>
      )}

      {!showAboutGroup && !showMembers && (
        <div className={`flex-1 overflow-y-auto p-4 relative ${isDarkTheme ? "bg-gray-900" : "bg-gray-100"}`}>
          <div className="absolute inset-0 pointer-events-none">
            <Star
              size={20}
              className={`absolute top-10 left-20 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-pulse`}
            />
            <Circle
              size={16}
              className={`absolute top-24 right-16 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-float`}
            />
            <Triangle
              size={18}
              className={`absolute bottom-20 left-32 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-bounce-slow`}
            />
            <Star
              size={14}
              className={`absolute bottom-32 right-24 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-pulse-delay`}
            />
            <Circle
              size={22}
              className={`absolute top-1/2 left-1/4 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-float-delay`}
            />
            <Triangle
              size={20}
              className={`absolute top-16 right-32 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-bounce-slow`}
            />
            <Star
              size={18}
              className={`absolute bottom-10 left-16 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-pulse`}
            />
            <Circle
              size={14}
              className={`absolute top-1/3 right-1/4 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-float`}
            />
            <Triangle
              size={16}
              className={`absolute bottom-1/4 left-1/2 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-bounce-slow`}
            />
            <Star
              size={22}
              className={`absolute top-1/4 right-1/3 ${isDarkTheme ? "text-gray-800" : "text-gray-300"} opacity-40 animate-pulse-delay`}
            />
          </div>
        </div>
      )}

      {!showAboutGroup && !showMembers && (
        <div className={`flex items-center p-4 ${isDarkTheme ? "bg-gray-800" : "bg-white"} shadow-md`}>
          <div className="relative">
            <button
              onClick={() => setShowEmojiPicker((prev) => !prev)}
              className={`${isDarkTheme ? "text-gray-300" : "text-gray-700"} hover:text-blue-500 mr-2`}
            >
              <Smile size={24} />
            </button>
            {showEmojiPicker && (
              <div className="absolute bottom-full left-0 mb-2 z-50">
                <EmojiPicker onEmojiClick={handleEmojiClick} theme={isDarkTheme ? "dark" : "light"} />
              </div>
            )}
          </div>
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className={`flex-1 p-2 rounded-lg border ${
              isDarkTheme ? "bg-gray-700 text-gray-100 border-gray-600" : "bg-white text-gray-800 border-gray-300"
            } focus:outline-none`}
            placeholder="Type a message..."
          />
          <button
            onClick={handleSendMessage}
            className={`${isDarkTheme ? "text-gray-300" : "text-gray-700"} hover:text-blue-500 ml-2`}
          >
            <Send size={24} />
          </button>
        </div>
      )}

      {/* Mobile bottom navbar (shown only for showProfile or showMembers) */}
      {(showProfile || showMembers) && (
        <div className={`md:hidden fixed bottom-0 left-0 right-0 ${currentTheme.sidebar} shadow-lg flex justify-around items-center py-2 z-50`}>
          {mobileBottomItems.map((item) => (
            <a
              key={item.id}
              href={item.route}
              onClick={(e) => handleSectionChange(e, item.id)}
              className={mobileNavItemClass(activeSection === item.id, item.isHighlight)}
            >
              {activeSection === item.id && (
                <span 
                  className="absolute inset-0 bg-gradient-to-t from-white/20 to-transparent 
                  rounded-full opacity-30 transform scale-150 pointer-events-none"
                  style={{
                    backgroundImage: 'radial-gradient(circle at 50% 70%, rgba(255,255,255,0.25), transparent)',
                  }}
                />
              )}
              <item.icon 
                size={item.isHighlight ? 28 : 22}
                className={`relative z-10 transition-transform duration-300 
                  ${activeSection === item.id && !item.isHighlight ? 'scale-125' : ''}`}
              />
            </a>
          ))}
        </div>
      )}
    </div>
  );
};

const styles = `
  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
  }
  @keyframes float-delay {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-15px); }
  }
  @keyframes bounce-slow {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-8px); }
  }
  .animate-float { animation: float 6s ease-in-out infinite; }
  .animate-float-delay { animation: float-delay 5s ease-in-out infinite 1s; }
  .animate-bounce-slow { animation: bounce-slow 4s ease-in-out infinite; }
  .animate-pulse-delay { animation: pulse 3s ease-in-out infinite 0.5s; }
  .scrollbar-hidden::-webkit-scrollbar {
    display: none;
  }
  .scrollbar-hidden {
    -ms-overflow-style: none;
    scrollbar-width: none;
  }
`;
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = styles;
document.head.appendChild(styleSheet);

export default React.memo(GroupChat);