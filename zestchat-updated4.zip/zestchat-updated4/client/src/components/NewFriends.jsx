import React from 'react';

const NewFriends = () => {
  const isDarkTheme = localStorage.getItem('zestchat-theme') === 'dark';

  return (
    <div className={`p-6 min-h-screen ${isDarkTheme ? 'bg-gray-900 text-gray-100' : 'bg-gray-100 text-gray-800'}`}>
      <h2 className="text-2xl font-bold mb-4">New Friends</h2>
      <p>This is the New Friends section. Find and visit random profiles here! (Coming Soon)</p>
    </div>
  );
};

export default NewFriends;