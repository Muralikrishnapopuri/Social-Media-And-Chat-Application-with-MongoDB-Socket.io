import { useState, useEffect } from 'react';
import { 
  Users, 
  UserPlus, 
  UserX, 
  Search,
  ChevronRight 
} from 'lucide-react';

const Chat = () => {
  const [activeTab, setActiveTab] = useState('friends');
  const [theme, setTheme] = useState(() => {
    const storedTheme = localStorage.getItem("zestchat-theme");
    console.log("Chat - Initial theme from localStorage:", storedTheme);
    return storedTheme === 'dark' ? 'dark' : 'light';
  });

  useEffect(() => {
    const handleStorageChange = (event) => {
      if (event.key === "zestchat-theme") {
        const newTheme = event.newValue === 'dark' ? 'dark' : 'light';
        console.log("Chat - Theme changed via storage event:", newTheme);
        setTheme(newTheme);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    const interval = setInterval(() => {
      const currentTheme = localStorage.getItem("zestchat-theme");
      if (currentTheme && currentTheme !== theme) {
        console.log("Chat - Polled theme change:", currentTheme);
        setTheme(currentTheme === 'dark' ? 'dark' : 'light');
      }
    }, 500);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, [theme]);

  useEffect(() => {
    console.log("Chat - Applying theme:", theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const navItems = [
    { id: 'friends', label: 'Friends', icon: Users },
    { id: 'requests', label: 'Requests', icon: UserPlus },
    { id: 'blocked', label: 'Blocked', icon: UserX },
  ];

  const themeStyles = {
    light: {
      bg: 'bg-gradient-to-br from-gray-100 via-gray-200 to-gray-300',
      text: 'text-gray-800',
      card: 'bg-white bg-opacity-80',
      hover: 'hover:bg-gray-200',
      button: 'bg-gradient-to-r from-blue-500 to-blue-700 text-white hover:from-blue-600 hover:to-blue-800',
      border: 'border-gray-300',
      secondary: 'text-gray-600',
      input: 'bg-white border-gray-300 text-gray-800',
      placeholder: 'placeholder-gray-400'
    },
    dark: {
      bg: 'bg-gradient-to-br from-gray-700 via-gray-800 to-gray-900',
      text: 'text-gray-100',
      card: 'bg-gray-800 bg-opacity-80',
      hover: 'hover:bg-gray-700',
      button: 'bg-gradient-to-r from-blue-500 to-blue-700 text-white hover:from-blue-600 hover:to-blue-800',
      border: 'border-gray-600',
      secondary: 'text-gray-300',
      input: 'bg-gray-700 border-gray-600 text-gray-100',
      placeholder: 'placeholder-gray-500'
    }
  };

  const currentTheme = theme === 'dark' ? themeStyles.dark : themeStyles.light;

  return (
    <div className={`min-h-screen font-sans antialiased transition-colors duration-300 ${currentTheme.bg} ${currentTheme.text} overflow-y-auto relative`}>
      {/* Background Particles */}
      <div className="absolute top-10 left-10 w-32 h-32 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full opacity-10 blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-40 h-40 bg-gradient-to-r from-purple-400 to-purple-600 rounded-lg opacity-15 blur-3xl animate-float"></div>
      <div className="absolute top-1/3 left-1/4 w-24 h-24 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full opacity-10 blur-2xl animate-bounce-slow"></div>

      {/* Header Navigation */}
      <header className={`sticky top-0 mt-4 sm:mt-0 custom-mt-640-767 z-10 backdrop-blur-md border-b shadow-lg ${theme === 'dark' ? 'bg-gray-800 bg-opacity-80 border-gray-600' : 'bg-white bg-opacity-80 border-gray-300'}`}>
        <div className="container mx-auto px-4 py-3 sm:py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <nav className={`flex w-full sm:w-auto justify-center rounded-full p-1.5 shadow-inner ${theme === 'dark' ? 'bg-gray-700 bg-opacity-50' : 'bg-gray-100 bg-opacity-50'}`}>
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex items-center px-3 py-2 sm:px-4 sm:py-2.5 rounded-full text-sm font-medium transition-all duration-300 ease-in-out group
                    ${activeTab === item.id 
                      ? `${theme === 'dark' ? 'bg-gray-700 text-gray-100 shadow-md' : 'bg-white text-gray-800 shadow-md'}`
                      : `${theme === 'dark' ? 'text-gray-300 hover:text-gray-100 hover:bg-gray-700' : 'text-gray-600 hover:text-gray-800 hover:bg-gray-200'}`
                    }`}
                >
                  <span className="sm:hidden">{item.label}</span>
                  <div className="hidden sm:flex items-center">
                    <item.icon className={`w-4 h-4 sm:w-5 sm:h-5 mr-2 ${currentTheme.secondary}`} />
                    <span>{item.label}</span>
                  </div>
                  <span className={`sm:hidden absolute -top-8 left-1/2 transform -translate-x-1/2 text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 shadow ${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-600'}`}>
                    {item.label}
                  </span>
                </button>
              ))}
            </nav>
            
            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 ${currentTheme.secondary}`} />
              <input
                type="text"
                placeholder="Search by name"
                className={`w-full pl-10 pr-4 py-2.5 rounded-full text-sm focus:outline-none focus:ring-2 transition-all duration-300 ${currentTheme.input} focus:ring-blue-200 ${currentTheme.placeholder}`}
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 relative z-10">
        <div className={`backdrop-blur-md rounded-3xl shadow-lg ${currentTheme.card} ${currentTheme.border} p-4 sm:p-6`}>
          {activeTab === 'friends' && (
            <section className="animate-fade-in">
              <h2 className={`text-lg sm:text-xl font-semibold mb-4 ${currentTheme.text}`}>My Friends</h2>
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div 
                    key={i}
                    className={`flex items-center justify-between p-3 rounded-xl transition-all duration-300 ${currentTheme.border} ${currentTheme.hover}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full shadow-inner bg-gradient-to-br ${theme === 'dark' ? 'from-gray-600 to-gray-700' : 'from-gray-200 to-gray-300'}`} />
                      <span className={`font-medium ${currentTheme.text}`}>Friend {i}</span>
                    </div>
                    <ChevronRight className={`w-5 h-5 ${currentTheme.secondary}`} />
                  </div>
                ))}
              </div>
            </section>
          )}

          {activeTab === 'requests' && (
            <section className="animate-fade-in">
              <h2 className={`text-lg sm:text-xl font-semibold mb-4 ${currentTheme.text}`}>Friend Requests</h2>
              <div className="space-y-3">
                {[1, 2].map((i) => (
                  <div 
                    key={i}
                    className={`flex flex-col sm:flex-row items-center justify-between p-3 rounded-xl transition-all duration-300 ${currentTheme.border} ${currentTheme.hover} gap-2`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full shadow-inner bg-gradient-to-br ${theme === 'dark' ? 'from-gray-600 to-gray-700' : 'from-gray-200 to-gray-300'}`} />
                      <span className={`font-medium ${currentTheme.text}`}>Request {i}</span>
                    </div>
                    <div className="flex space-x-2">
                      <button className={`px-4 py-1.5 rounded-full text-sm transition-all duration-200 shadow-sm ${currentTheme.button}`}>
                        Accept
                      </button>
                      <button className={`px-4 py-1.5 rounded-full text-sm transition-all duration-200 shadow-sm ${theme === 'dark' ? 'bg-gray-600 text-gray-300 hover:bg-gray-700' : 'bg-gray-200 text-gray-600 hover:bg-gray-300'}`}>
                        Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {activeTab === 'blocked' && (
            <section className="animate-fade-in">
              <h2 className={`text-lg sm:text-xl font-semibold mb-4 ${currentTheme.text}`}>Blocked People</h2>
              <div className="space-y-3">
                {[1, 2].map((i) => (
                  <div 
                    key={i}
                    className={`flex items-center justify-between p-3 rounded-xl transition-all duration-300 ${currentTheme.border} ${currentTheme.hover}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full shadow-inner bg-gradient-to-br ${theme === 'dark' ? 'from-gray-600 to-gray-700' : 'from-gray-200 to-gray-300'}`} />
                      <span className={`font-medium ${currentTheme.text}`}>Blocked {i}</span>
                    </div>
                    <button className={`px-4 py-1.5 rounded-full text-sm transition-all duration-200 shadow-sm ${theme === 'dark' ? 'bg-gray-600 text-gray-300 hover:bg-gray-700' : 'bg-gray-200 text-gray-600 hover:bg-gray-300'}`}>
                      Unblock
                    </button>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
};

const customStyles = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-20px); }
  }
  @keyframes bounce-slow {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
  }
  .animate-fade-in { animation: fadeIn 0.3s ease-out; }
  .animate-float { animation: float 6s ease-in-out infinite; }
  .animate-bounce-slow { animation: bounce-slow 4s ease-in-out infinite; }
  @media (min-width: 640px) and (max-width: 767px) {
    .custom-mt-640-767 {
      margin-top: 1rem;
    }
  }
`;

const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = customStyles;
document.head.appendChild(styleSheet);

export default Chat;