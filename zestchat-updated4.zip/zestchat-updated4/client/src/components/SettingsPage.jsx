import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { User, Lock, MapPin, Users, Info, Camera, X, Save } from 'react-feather';

const Settings = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    password: '',
    age: '',
    location: '',
    gender: '',
    bio: '',
    profile_pic: null,
  });
  const [previewImage, setPreviewImage] = useState(null);

  const isDarkTheme = localStorage.getItem('zestchat-theme') === 'dark';
  const navigate = useNavigate();
  const token = JSON.parse(localStorage.getItem('zestchat-user'))?.token;
  const API_URL = import.meta.env.VITE_API_URL;

  // Fetch current user profile
  const fetchProfile = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.get(`${API_URL}/api/users/profile`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setUser(response.data.user);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load profile');
      if (err.response?.status === 401) {
        localStorage.removeItem('zestchat-user');
        navigate('/join-chat');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (token) {
      fetchProfile();
    } else {
      navigate('/join-chat');
    }
  }, [navigate, token]);

  // Populate form data when modal opens
  const openModal = () => {
    if (user) {
      setFormData({
        password: '',
        age: user.age || '',
        location: user.location || '',
        gender: user.gender || '',
        bio: user.bio || '',
        profile_pic: null,
      });
      setPreviewImage(user.profile_pic ? `${API_URL}${user.profile_pic}` : null);
    }
    setIsModalOpen(true);
  };

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, profile_pic: file });
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  // Handle image removal by calling DELETE endpoint
  const handleRemoveImage = async () => {
    try {
      setLoading(true);
      await axios.delete(`${API_URL}/api/users/profile-pic`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUser({ ...user, profile_pic: null });
      setPreviewImage(null);
      setFormData({ ...formData, profile_pic: null });
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to remove profile picture');
    } finally {
      setLoading(false);
    }
  };

  // Update profile
  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const updateData = new FormData();
    if (formData.password) updateData.append('password', formData.password);
    if (formData.age) updateData.append('age', formData.age);
    if (formData.location) updateData.append('location', formData.location);
    if (formData.gender) updateData.append('gender', formData.gender);
    if (formData.bio) updateData.append('bio', formData.bio);
    if (formData.profile_pic) updateData.append('profile_pic', formData.profile_pic);

    try {
      const response = await axios.put(`${API_URL}/api/users/update`, updateData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
      });

      setUser(response.data.user);
      setIsModalOpen(false);
      setFormData({ password: '', age: '', location: '', gender: '', bio: '', profile_pic: null });
      setPreviewImage(null);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update profile');
      if (err.response?.status === 401) {
        localStorage.removeItem('zestchat-user');
        navigate('/join-chat');
      }
    } finally {
      setLoading(false);
    }
  };

  // Theme styles
  const themeStyles = {
    light: {
      bg: 'bg-gradient-to-br from-gray-100 via-gray-200 to-gray-300',
      text: 'text-gray-800',
      card: 'bg-white bg-opacity-80',
      hover: 'hover:bg-gray-200',
      button: 'bg-gradient-to-r from-blue-500 to-blue-700 text-white hover:from-blue-600 hover:to-blue-800',
    },
    dark: {
      bg: 'bg-gradient-to-br from-gray-700 via-gray-800 to-gray-900',
      text: 'text-gray-100',
      card: 'bg-gray-800 bg-opacity-80',
      hover: 'hover:bg-gray-700',
      button: 'bg-gradient-to-r from-blue-500 to-blue-700 text-white hover:from-blue-600 hover:to-blue-800',
    },
  };

  const currentTheme = isDarkTheme ? themeStyles.dark : themeStyles.light;

  // Frame styles based on level (Bronze for now)
  const getFrameStyle = (level) => {
    switch (level) {
      case 'Bronze':
        return {
          background: 'radial-gradient(circle, #cd7f32 10%, #8c5523 70%, #5c4033 100%)',
          borderRadius: '50%',
          padding: '8px',
          boxShadow: '0 0 10px rgba(205, 127, 50, 0.8), inset 0 0 5px rgba(0, 0, 0, 0.5)',
          border: '4px solid #cd7f32',
        };
      default:
        return {};
    }
  };

  if (loading && !user) {
    return (
      <div className={`flex h-screen items-center justify-center ${currentTheme.bg}`}>
        <div className="flex space-x-2">
          <div className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'}`} style={{ animationDelay: '0s' }}></div>
          <div className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'}`} style={{ animationDelay: '0.2s' }}></div>
          <div className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'}`} style={{ animationDelay: '0.4s' }}></div>
        </div>
      </div>
    );
  }

  return (
    <div className={`p-6 min-h-screen ${currentTheme.bg} ${currentTheme.text} overflow-y-auto relative`}>
      {/* Background blur objects */}
      <div className="absolute top-0 left-0 w-40 h-40 bg-blue-300 rounded-full opacity-20 blur-xl -translate-x-20 -translate-y-20"></div>
      <div className="absolute bottom-0 right-0 w-32 h-32 bg-purple-300 rounded-full opacity-20 blur-xl translate-x-16 translate-y-16"></div>
      <div className="absolute top-1/2 left-1/2 w-48 h-48 bg-pink-300 rounded-full opacity-20 blur-xl -translate-x-1/2 -translate-y-1/2"></div>

   

      {error && <p className="text-red-500 text-center mb-4">{error}</p>}

      {user && (
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Profile Section */}
          <div className={`p-6 rounded-lg shadow-lg ${currentTheme.card} backdrop-blur-md text-center`}>
            <div className="relative inline-block">
              <div style={getFrameStyle(user.level)} className="relative">
                {user.profile_pic ? (
                  <img
                    src={`${API_URL}${user.profile_pic}`}
                    alt="Profile"
                    className="w-32 h-32 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-32 h-32 rounded-full bg-gray-300 flex items-center justify-center">
                    <User size={64} className={isDarkTheme ? 'text-gray-600' : 'text-gray-400'} />
                  </div>
                )}
              </div>
              <span className="absolute top-0 right-0 bg-gradient-to-r from-purple-500 to-indigo-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
                {user.level}
              </span>
            </div>
            <h3 className="text-xl font-semibold mt-4">{user.username}</h3>
            <p className="text-sm">{user.age !== 'none' ? `${user.age} years` : 'Age not specified'}</p>
            <button
              onClick={openModal}
              className={`mt-4 px-4 py-2 ${currentTheme.button} rounded-lg shadow-md transition duration-300`}
            >
              Edit Profile
            </button>
          </div>

          {/* Followers and Following */}
          <div className={`p-6 rounded-lg shadow-lg ${currentTheme.card} backdrop-blur-md`}>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <p className="font-semibold">Followers</p>
                <p>{user.followers.length}</p>
              </div>
              <div>
                <p className="font-semibold">Following</p>
                <p>{user.following.length}</p>
              </div>
            </div>
          </div>

          {/* Bio */}
          <div className={`p-6 rounded-lg shadow-lg ${currentTheme.card} backdrop-blur-md`}>
            <h4 className="font-semibold mb-2">Bio</h4>
            <p>{user.bio || 'No bio provided'}</p>
          </div>

          {/* Profile Visibility */}
          <div className={`p-6 rounded-lg shadow-lg ${currentTheme.card} backdrop-blur-md`}>
            <h4 className="font-semibold mb-4">Profile Visibility</h4>
            <div className="grid grid-cols-2 gap-4">
              <button
                className={`p-4 rounded-lg ${user.profile === 'public' ? 'bg-gradient-to-r from-green-500 to-green-700 text-white' : `${currentTheme.hover} ${currentTheme.text}`} shadow-md`}
                disabled={true}
              >
                Public
              </button>
              <button
                className={`p-4 rounded-lg ${user.profile === 'private' ? 'bg-gradient-to-r from-red-500 to-pink-500 text-white' : `${currentTheme.hover} ${currentTheme.text}`} shadow-md`}
                disabled={true}
              >
                Private
              </button>
            </div>
          </div>

          {/* User Details */}
          <div className={`p-6 rounded-lg shadow-lg ${currentTheme.card} backdrop-blur-md`}>
            <h4 className="font-semibold mb-4">Profile Details</h4>
            <div className="space-y-2">
              <p><span className="font-medium">Email:</span> {user.email}</p>
              <p><span className="font-medium">Gender:</span> {user.gender}</p>
              <p><span className="font-medium">Location:</span> {user.location || 'Not specified'}</p>
              <p><span className="font-medium">Own Groups Count:</span> {user.own_groups_count}</p>
            </div>
          </div>

          {/* Delete Account */}
          <div className="text-center">
            <button
              className="px-6 py-3 bg-gradient-to-r from-red-600 to-red-800 text-white rounded-lg shadow-md hover:from-red-700 hover:to-red-900 transition duration-300"
              onClick={() => alert('Delete Account functionality not implemented yet')}
            >
              Delete Account Permanently
            </button>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className={`p-6 rounded-lg shadow-lg ${currentTheme.card} backdrop-blur-md w-full max-w-lg`}>
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <User className="mr-2" /> Edit Profile
            </h3>
            <form onSubmit={handleUpdateProfile} className="space-y-4 md:grid md:grid-cols-2 md:gap-4 md:space-y-0">
              <div className="relative">
                <label className="block text-sm font-medium mb-1 flex items-center">
                  <Lock className="mr-2" /> Password
                </label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className={`w-full p-2 pl-8 rounded-lg border ${isDarkTheme ? 'bg-gray-700 text-gray-100 border-gray-600' : 'bg-white text-gray-800 border-gray-300'} focus:outline-none focus:ring-2 focus:ring-blue-200`}
                  placeholder="New password (optional)"
                />
              </div>
              <div className="relative">
                <label className="block text-sm font-medium mb-1 flex items-center">
                  <User className="mr-2" /> Age
                </label>
                <input
                  type="text"
                  name="age"
                  value={formData.age}
                  onChange={handleInputChange}
                  className={`w-full p-2 pl-8 rounded-lg border ${isDarkTheme ? 'bg-gray-700 text-gray-100 border-gray-600' : 'bg-white text-gray-800 border-gray-300'} focus:outline-none focus:ring-2 focus:ring-blue-200`}
                  placeholder="Enter age"
                />
              </div>
              <div className="relative">
                <label className="block text-sm font-medium mb-1 flex items-center">
                  <MapPin className="mr-2" /> Location
                </label>
                <input
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  className={`w-full p-2 pl-8 rounded-lg border ${isDarkTheme ? 'bg-gray-700 text-gray-100 border-gray-600' : 'bg-white text-gray-800 border-gray-300'} focus:outline-none focus:ring-2 focus:ring-blue-200`}
                  placeholder="Enter location"
                />
              </div>
              <div className="relative">
                <label className="block text-sm font-medium mb-1 flex items-center">
                  <Users className="mr-2" /> Gender
                </label>
                <select
                  name="gender"
                  value={formData.gender}
                  onChange={handleInputChange}
                  className={`w-full p-2 pl-8 rounded-lg border ${isDarkTheme ? 'bg-gray-700 text-gray-100 border-gray-600' : 'bg-white text-gray-800 border-gray-300'} focus:outline-none focus:ring-2 focus:ring-blue-200`}
                >
                  <option value="">Select gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="relative md:col-span-2">
                <label className="block text-sm font-medium mb-1 flex items-center">
                  <Info className="mr-2" /> Bio
                </label>
                <textarea
                  name="bio"
                  value={formData.bio}
                  onChange={handleInputChange}
                  className={`w-full p-2 pl-8 rounded-lg border ${isDarkTheme ? 'bg-gray-700 text-gray-100 border-gray-600' : 'bg-white text-gray-800 border-gray-300'} focus:outline-none focus:ring-2 focus:ring-blue-200`}
                  placeholder="Enter bio"
                />
              </div>
              <div className="relative md:col-span-2">
                <label className="block text-sm font-medium mb-1 flex items-center">
                  <Camera className="mr-2" /> Profile Picture
                </label>
                <div className="flex items-center space-x-4">
                  {previewImage ? (
                    <div className="relative">
                      <img
                        src={previewImage}
                        alt="Preview"
                        className="w-20 h-20 rounded-full object-cover border-2 border-gray-300"
                      />
                      <button
                        type="button"
                        onClick={handleRemoveImage}
                        className="absolute top-0 right-0 bg-red-500 text-white rounded-full p-1"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <div className="relative">
                      <div className="w-20 h-20 rounded-full bg-gray-300 flex items-center justify-center border-2 border-gray-300">
                        <User size={40} className={isDarkTheme ? 'text-gray-600' : 'text-gray-400'} />
                      </div>
                    </div>
                  )}
                  <label
                    htmlFor="profile_pic"
                    className={`flex items-center justify-center w-full p-3 border-2 border-dashed ${isDarkTheme ? 'border-gray-600 bg-gray-700' : 'border-gray-300 bg-gray-100'} rounded-lg cursor-pointer hover:${currentTheme.hover} transition`}
                  >
                    <Camera className="mr-2" />
                    <span>{formData.profile_pic ? 'Change Image' : 'Upload Image'}</span>
                    <input
                      id="profile_pic"
                      type="file"
                      name="profile_pic"
                      onChange={handleFileChange}
                      className="hidden"
                      accept="image/*"
                    />
                  </label>
                </div>
              </div>
              {error && <p className="text-red-500 text-sm md:col-span-2">{error}</p>}
              <div className="flex justify-end space-x-2 md:col-span-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className={`px-4 py-2 ${isDarkTheme ? 'bg-gray-600 hover:bg-gray-700' : 'bg-gray-300 hover:bg-gray-400'} rounded flex items-center`}
                  disabled={loading}
                >
                  <X className="mr-2" /> Cancel
                </button>
                <button
                  type="submit"
                  className={`px-4 py-2 ${currentTheme.button} rounded flex items-center ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
                  disabled={loading}
                >
                  <Save className="mr-2" /> Update
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Loader Overlay */}
      {loading && user && (
        <div className="fixed inset-0 flex justify-center items-center z-[1000] bg-black bg-opacity-50">
          <div className="flex space-x-2">
            <div className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'}`} style={{ animationDelay: '0s' }}></div>
            <div className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'}`} style={{ animationDelay: '0.2s' }}></div>
            <div className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'}`} style={{ animationDelay: '0.4s' }}></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Settings;