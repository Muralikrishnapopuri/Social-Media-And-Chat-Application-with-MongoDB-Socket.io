import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Plus, Edit2, Trash2, Rss, Users, X, Save, Image as ImageIcon } from 'react-feather';

const Groups = () => {
  const [groups, setGroups] = useState([]);
  const [groupTitle, setGroupTitle] = useState('');
  const [description, setDescription] = useState('');
  const [groupPic, setGroupPic] = useState(null);
  const [previewImage, setPreviewImage] = useState(null);
  const [editGroupId, setEditGroupId] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [viewMode, setViewMode] = useState('my');
  const [loading, setLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const userData = JSON.parse(localStorage.getItem('zestchat-user'));
  const token = userData?.token;
  const owner = userData?.username;
  const navigate = useNavigate();
  const isDarkTheme = localStorage.getItem('zestchat-theme') === 'dark';

  const fetchGroups = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:5000/api/groups');
      setGroups(response.data);
    } catch (err) {
      setError('Failed to fetch groups');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGroups();
  }, []);

  const handleShowAllGroups = () => {
    if (viewMode !== 'all') {
      setError('');
      setSuccess('');
      fetchGroups().then(() => setViewMode('all'));
    }
  };

  const handleCreateGroup = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    if (!token) {
      setError('No valid token found. Please log in again.');
      navigate('/join-chat');
      setLoading(false);
      return;
    }

    const formData = new FormData();
    formData.append('group_title', groupTitle);
    formData.append('description', description);
    formData.append('owner', owner);
    if (groupPic) formData.append('group_pic', groupPic);

    try {
      const response = await axios.post(
        'http://localhost:5000/api/groups/create',
        formData,
        { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'multipart/form-data' } }
      );
      setGroups([...groups, response.data.group]);
      setSuccess('Group created successfully');
      setGroupTitle('');
      setDescription('');
      setGroupPic(null);
      setPreviewImage(null);
      setIsModalOpen(false);
      setViewMode('my');
    } catch (err) {
      if (err.response?.status === 401) {
        setError('Token is not valid. Please log in again.');
        localStorage.removeItem('zestchat-user');
        navigate('/join-chat');
      } else {
        setError(err.response?.data?.message || 'Failed to create group');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEditGroup = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    if (!token) {
      setError('No valid token found. Please log in again.');
      navigate('/join-chat');
      setLoading(false);
      return;
    }

    const formData = new FormData();
    formData.append('group_title', groupTitle);
    formData.append('description', description);
    formData.append('owner', owner);
    if (groupPic) formData.append('group_pic', groupPic);

    try {
      const response = await axios.put(
        `http://localhost:5000/api/groups/edit/${editGroupId}`,
        formData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setGroups(groups.map(g => g.group_id === editGroupId ? response.data.group : g));
      setSuccess('Group updated successfully');
      setEditGroupId(null);
      setGroupTitle('');
      setDescription('');
      setGroupPic(null);
      setPreviewImage(null);
      setIsModalOpen(false);
      setViewMode('all');
    } catch (err) {
      if (err.response?.status === 401) {
        setError('Token is not valid. Please log in again.');
        localStorage.removeItem('zestchat-user');
        navigate('/join-chat');
      } else {
        setError(err.response?.data?.message || 'Failed to edit group');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteGroup = async (groupId) => {
    setError('');
    setSuccess('');
    setLoading(true);

    if (!token) {
      setError('No valid token found. Please log in again.');
      navigate('/join-chat');
      setLoading(false);
      return;
    }

    try {
      await axios.delete(`http://localhost:5000/api/groups/delete/${groupId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setGroups(groups.filter(g => g.group_id !== groupId));
      setSuccess('Group deleted successfully');
    } catch (err) {
      if (err.response?.status === 401) {
        setError('Token is not valid. Please log in again.');
        localStorage.removeItem('zestchat-user');
        navigate('/join-chat');
      } else {
        setError(err.response?.data?.message || 'Failed to delete group');
      }
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (group) => {
    setEditGroupId(group.group_id);
    setGroupTitle(group.group_title);
    setDescription(group.description);
    setGroupPic(null);
    setPreviewImage(group.group_pic);
    setIsModalOpen(true);
  };

  const handleGroupClick = async (group) => {
    if (!token) {
      setError('No valid token found. Please log in again.');
      navigate('/join-chat');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(
        `http://localhost:5000/api/groups/join/${group.group_id}`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (response.status === 200) {
        setGroups(groups.map(g => g.group_id === group.group_id ? response.data.group : g));
        setSuccess('Successfully joined group');
      }
    } catch (err) {
      if (err.response?.status === 401) {
        setError('Token is not valid. Please log in again.');
        localStorage.removeItem('zestchat-user');
        navigate('/join-chat');
      } else if (err.response?.status === 403) {
        setError(err.response.data.message || 'You are blocked from joining this group');
      } else if (err.response?.status !== 204) {
        setError(err.response?.data?.message || 'Failed to join group');
      }
    } finally {
      setLoading(false);
    }

    navigate(`/live/group/${group.group_id}`, {
      state: { groupTitle: group.group_title, groupPic: group.group_pic, reset: true },
    });
  };

  const canEditGroup = (group) => {
    return group.owner === owner || (group.admins && group.admins.includes(owner));
  };

  const myGroups = groups.filter(group => 
    group.users_array.includes(owner) || canEditGroup(group)
  );

  const availableGroups = groups.filter(group => 
    !group.users_array.includes(owner) && !canEditGroup(group)
  );

  const handleShowMyGroups = () => {
    setViewMode('my');
    setError('');
    setSuccess('');
  };

  const handleShowCreateForm = () => {
    setEditGroupId(null);
    setGroupTitle('');
    setDescription('');
    setGroupPic(null);
    setPreviewImage(null);
    setError('');
    setSuccess('');
    setIsModalOpen(true);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setGroupPic(file);
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  const displayedGroups = viewMode === 'all' ? availableGroups : myGroups;

  // Theme styles similar to Settings component
  const themeStyles = {
    light: {
      bg: 'bg-gradient-to-br from-gray-100 via-gray-200 to-gray-300',
      text: 'text-gray-800',
      card: 'bg-white bg-opacity-80',
      hover: 'hover:bg-gray-200',
      button: 'bg-gradient-to-r from-blue-500 to-blue-700 text-white hover:from-blue-600 hover:to-blue-800',
    },
    dark: {
      bg: 'bg-gradient-to-br from-gray-700 via-gray-800 to-gray-900',
      text: 'text-gray-100',
      card: 'bg-gray-800 bg-opacity-80',
      hover: 'hover:bg-gray-700',
      button: 'bg-gradient-to-r from-blue-500 to-blue-700 text-white hover:from-blue-600 hover:to-blue-800',
    },
  };

  const currentTheme = isDarkTheme ? themeStyles.dark : themeStyles.light;

  return (
    <div className={`p-6 min-h-screen ${currentTheme.bg} ${currentTheme.text} overflow-y-auto relative`}>
      {/* Apple-like background particles */}
      <div className="absolute top-10 left-10 w-32 h-32 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full opacity-10 blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-40 h-40 bg-gradient-to-r from-purple-400 to-purple-600 rounded-lg opacity-15 blur-3xl animate-float"></div>
      <div className="absolute top-1/3 left-1/4 w-24 h-24 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full opacity-10 blur-2xl animate-bounce-slow"></div>
      <div className="absolute bottom-1/4 right-1/3 w-28 h-28 bg-gradient-to-r from-green-400 to-green-600 rounded-full opacity-12 blur-3xl animate-pulse-delay"></div>
      <div className="absolute top-1/2 left-1/2 w-36 h-36 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-lg opacity-15 blur-3xl animate-float-delay"></div>

      <div className="md:static sticky top-4 z-20 flex justify-center mb-8 py-4">
        <div className="flex rounded-full overflow-hidden shadow-lg">
          <div className="relative">
            <button
              onClick={handleShowAllGroups}
              className={`px-6 py-3 bg-gradient-to-r from-red-500 to-pink-700 text-white font-semibold hover:from-red-600 hover:to-pink-800 transition duration-300 ${loading || viewMode === 'all' ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={loading || viewMode === 'all'}
            >
              <Rss size={20} />
            </button>
            {viewMode === 'all' && (
              <div className={`absolute bottom-0 left-0 w-full h-1 ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'} transition-all duration-300`} />
            )}
          </div>
          <div className="relative">
            <button
              onClick={handleShowMyGroups}
              className={`px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-700 text-white font-semibold hover:from-blue-600 hover:to-blue-800 transition duration-300 ${loading || viewMode === 'my' ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={loading || viewMode === 'my'}
            >
              <Users size={20} />
            </button>
            {viewMode === 'my' && (
              <div className={`absolute bottom-0 left-0 w-full h-1 ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'} transition-all duration-300`} />
            )}
          </div>
          <div className="relative">
            <button
              onClick={handleShowCreateForm}
              className={`px-6 py-3 bg-gradient-to-r from-green-500 to-green-700 text-white font-semibold hover:from-green-600 hover:to-green-800 transition duration-300 ${loading || isModalOpen ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={loading || isModalOpen}
            >
              <Plus size={20} />
            </button>
            {isModalOpen && (
              <div className={`absolute bottom-0 left-0 w-full h-1 ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'} transition-all duration-300`} />
            )}
          </div>
        </div>
      </div>

      {loading && (
        <div className="fixed inset-0 flex justify-center items-center z-[1000] bg-black bg-opacity-50">
          <div className="flex space-x-2">
            <div className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'}`} style={{ animationDelay: '0s' }}></div>
            <div className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'}`} style={{ animationDelay: '0.2s' }}></div>
            <div className={`w-4 h-4 rounded-full animate-bounce ${isDarkTheme ? 'bg-blue-400' : 'bg-blue-600'}`} style={{ animationDelay: '0.4s' }}></div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pb-24 sm:pb-8 lg:pb-8 z-10">
        {displayedGroups.length === 0 && !loading ? (
          <p className={`text-center col-span-full ${isDarkTheme ? 'text-gray-400' : 'text-gray-500'}`}>
            {viewMode === 'all' ? 'No groups available to join yet.' : 'You are not a member, owner, or admin of any groups yet.'}
          </p>
        ) : (
          displayedGroups.map(group => (
            <div
              key={group.group_id}
              onClick={() => handleGroupClick(group)}
              className={`relative p-4 cursor-pointer ${currentTheme.card} backdrop-blur-md rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300 ease-in-out`}
            >
              {/* Label for owned or joined groups in "My Groups" view */}
              {viewMode === 'my' && (
                <div
                  className={`absolute top-0 right-0 w-6 h-6 transform rotate-45 translate-x-3 -translate-y-3 z-20 ${
                    group.owner === owner ? 'bg-green-500' : 'bg-sky-500'
                  }`}
                />
              )}
              <div className="flex items-center mb-3">
                {group.group_pic ? (
                  <img src={group.group_pic} alt={group.group_title} className="w-12 h-12 rounded-full object-cover mr-3 z-10" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-gray-300 flex items-center justify-center mr-3 z-10">
                    <ImageIcon size={24} className={isDarkTheme ? 'text-gray-600' : 'text-gray-400'} />
                  </div>
                )}
                <h3 className={`text-lg font-semibold z-10`}>{group.group_title}</h3>
              </div>

              <div className="h-16 overflow-hidden text-sm z-10">
                <p className={isDarkTheme ? 'text-gray-300' : 'text-gray-600'}>
                  {group.description || 'No description available'}
                </p>
              </div>

              <div className="mt-3 flex justify-between items-center z-10">
                <p className={`text-xs ${isDarkTheme ? 'text-gray-400' : 'text-gray-500'}`}>
                  Users: {group.total_users}
                </p>
                <div className="space-x-2 z-10">
                  {canEditGroup(group) && (
                    <>
                      <button
                        onClick={(e) => { e.stopPropagation(); startEdit(group); }}
                        className={`p-1 bg-transparent text-yellow-500 rounded-full hover:bg-gray-500 hover:bg-opacity-20 transition-colors duration-200 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
                        disabled={loading}
                      >
                        <Edit2 size={16} />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDeleteGroup(group.group_id); }}
                        className={`p-1 bg-transparent text-red-500 rounded-full hover:bg-gray-500 hover:bg-opacity-20 transition-colors duration-200 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
                        disabled={loading}
                      >
                        <Trash2 size={16} />
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Create/Edit Group Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className={`p-6 rounded-lg shadow-lg ${currentTheme.card} backdrop-blur-md w-full max-w-md`}>
            <h3 className="text-xl font-bold mb-4 flex items-center">
              {editGroupId ? 'Edit Group' : 'Create Group'}
            </h3>
            <form onSubmit={editGroupId ? handleEditGroup : handleCreateGroup} className="space-y-4">
              <div className="relative">
                <label className="block text-sm font-medium mb-1 flex items-center">
                  Group Title
                </label>
                <input
                  type="text"
                  value={groupTitle}
                  onChange={(e) => setGroupTitle(e.target.value)}
                  className={`w-full p-2 rounded-lg border ${isDarkTheme ? 'bg-gray-700 text-gray-100 border-gray-600' : 'bg-white text-gray-800 border-gray-300'} focus:outline-none focus:ring-2 focus:ring-blue-200`}
                  placeholder="Enter group title"
                  required
                  disabled={loading}
                />
              </div>
              <div className="relative">
                <label className="block text-sm font-medium mb-1 flex items-center">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className={`w-full p-2 rounded-lg border ${isDarkTheme ? 'bg-gray-700 text-gray-100 border-gray-600' : 'bg-white text-gray-800 border-gray-300'} focus:outline-none focus:ring-2 focus:ring-blue-200`}
                  placeholder="Enter group description"
                  disabled={loading}
                />
              </div>
              <div className="relative">
                <label className="block text-sm font-medium mb-1 flex items-center">
                  <ImageIcon className="mr-2" /> Group Picture
                </label>
                <div className="flex items-center space-x-4">
                  {previewImage ? (
                    <div className="relative">
                      <img
                        src={previewImage}
                        alt="Preview"
                        className="w-20 h-20 rounded-full object-cover border-2 border-gray-300"
                      />
                      <button
                        type="button"
                        onClick={() => { setGroupPic(null); setPreviewImage(null); }}
                        className="absolute top-0 right-0 bg-red-500 text-white rounded-full p-1"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <div className="relative">
                      <div className="w-20 h-20 rounded-full bg-gray-300 flex items-center justify-center border-2 border-gray-300">
                        <ImageIcon size={40} className={isDarkTheme ? 'text-gray-600' : 'text-gray-400'} />
                      </div>
                    </div>
                  )}
                  <label
                    htmlFor="group_pic"
                    className={`flex items-center justify-center w-full p-3 border-2 border-dashed ${isDarkTheme ? 'border-gray-600 bg-gray-700' : 'border-gray-300 bg-gray-100'} rounded-lg cursor-pointer hover:${currentTheme.hover} transition`}
                  >
                    <ImageIcon className="mr-2" />
                    <span>{groupPic ? 'Change Image' : 'Upload Image'}</span>
                    <input
                      id="group_pic"
                      type="file"
                      name="group_pic"
                      onChange={handleFileChange}
                      className="hidden"
                      accept="image/*"
                      disabled={loading}
                    />
                  </label>
                </div>
              </div>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              {success && <p className="text-green-500 text-sm">{success}</p>}
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className={`px-4 py-2 ${isDarkTheme ? 'bg-gray-600 hover:bg-gray-700' : 'bg-gray-300 hover:bg-gray-400'} rounded flex items-center`}
                  disabled={loading}
                >
                  <X className="mr-2" /> Cancel
                </button>
                <button
                  type="submit"
                  className={`px-4 py-2 ${currentTheme.button} rounded flex items-center ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
                  disabled={loading}
                >
                  <Save className="mr-2" /> {editGroupId ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// Custom animations for particles
const styles = `
  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-20px); }
  }
  @keyframes float-delay {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-15px); }
  }
  @keyframes bounce-slow {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
  }
  .animate-float { animation: float 6s ease-in-out infinite; }
  .animate-float-delay { animation: float-delay 5s ease-in-out infinite 1s; }
  .animate-bounce-slow { animation: bounce-slow 4s ease-in-out infinite; }
  .animate-pulse-delay { animation: pulse 3s ease-in-out infinite 0.5s; }
`;
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = styles;
document.head.appendChild(styleSheet);

export default Groups;