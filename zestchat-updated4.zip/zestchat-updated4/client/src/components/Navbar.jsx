import React, { useState } from "react";
import { Link } from "react-router-dom";
import logo from "../assets/logo.png";

function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  return (
    <nav className="bg-gradient-to-r from-purple-900 to-blue-900 p-4 shadow-lg">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        {/* Logo and Title */}
        <div className="flex items-center space-x-2">
          <img src={logo} alt="ZestChat Logo" className="h-8 w-8" />
          <h1 className="text-white text-2xl font-bold whitespace-nowrap">
            ZestChat
          </h1>
        </div>

        {/* Hamburger Menu Button (visible on mobile) */}
        <button
          className="md:hidden text-white focus:outline-none"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d={
                isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"
              }
            ></path>
          </svg>
        </button>

        {/* Navigation Links (Desktop: inline, Mobile: hidden or dropdown) */}
        <div
          className={`md:flex md:space-x-6 ${
            isMenuOpen ? "flex" : "hidden"
          } md:block absolute md:static top-16 left-0 right-0 bg-gradient-to-r  from-purple-900 to-blue-900 md:bg-transparent flex-col md:flex-row items-center p-4 md:p-0 shadow-lg md:shadow-none z-50`}
        >
          <Link
            to="/"
            className="text-white hover:text-blue-200 transition duration-300 ease-in-out py-2 md:py-0 w-full md:w-auto text-center"
            onClick={() => setIsMenuOpen(false)}
          >
            Home
          </Link>
          <Link
            to="/about"
            className="text-white hover:text-blue-200 transition duration-300 ease-in-out py-2 md:py-0 w-full md:w-auto text-center"
            onClick={() => setIsMenuOpen(false)}
          >
            About
          </Link>
          <Link
            to="/join-chat"
            className="text-white hover:text-blue-200 transition duration-300 ease-in-out py-2 md:py-0 w-full md:w-auto text-center"
            onClick={() => setIsMenuOpen(false)}
          >
            Join Chat
          </Link>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
