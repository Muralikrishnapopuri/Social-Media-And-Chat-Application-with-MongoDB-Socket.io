import React, { useEffect, useState, useMemo, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { 
  ArrowLeftIcon, 
  UserIcon, 
  MapPinIcon, 
  LockClosedIcon, 
  LockOpenIcon, 
  HomeIcon, 
  ChatBubbleLeftIcon, 
  ShoppingBagIcon, 
  HeartIcon, 
  CogIcon, 
  UserMinusIcon, 
  SlashIcon,
  CalendarIcon,
  StarIcon,
  InformationCircleIcon
} from '@heroicons/react/24/outline';
import axios from 'axios';
import { motion, AnimatePresence } from 'framer-motion';

const Profile = ({ username: propUsername, onBack, activeSection, handleSectionChange }) => {
  const navigate = useNavigate();
  const { username: routeUsername } = useParams();
  const username = propUsername || routeUsername;
  const [userData, setUserData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [toaster, setToaster] = useState({ message: '', type: '', visible: false });
  const [isFollowing, setIsFollowing] = useState(false);
  const [blocklist, setBlocklist] = useState([]);
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef(null);

  const isDarkTheme = localStorage.getItem('zestchat-theme') === 'dark';
  const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';
  const currentUser = JSON.parse(localStorage.getItem('zestchat-user'))?.username;

  // Sidebar-related logic
  const themes = useMemo(() => ({
    light: {
      sidebar: 'bg-gradient-to-b from-gray-50 to-gray-100',
      content: 'bg-gradient-to-br from-gray-100 via-gray-200 to-gray-300',
      text: 'text-black-100',
      hover: 'hover:bg-opacity-30 hover:bg-sky-900',
      active: 'bg-gradient-to-l from-red-500 to-pink-500',
      highlight: 'bg-gradient-to-l from-purple-500 to-indigo-500'
    },
    dark: {
      sidebar: 'bg-gradient-to-b from-gray-900 to-black',
      content: 'bg-gradient-to-br from-gray-700 via-gray-800 to-gray-900',
      text: 'text-white',
      hover: 'hover:bg-opacity-10 hover:bg-sky-100',
      active: 'bg-gradient-to-l from-red-500 to-pink-500',
      highlight: 'bg-gradient-to-l from-purple-600 to-indigo-600'
    }
  }), []);

  const currentTheme = isDarkTheme ? themes.dark : themes.light;

  const mobileBottomItems = useMemo(() => [
    { id: 'home', icon: HomeIcon, label: 'Home', route: '/live' },
    { id: 'chat', icon: ChatBubbleLeftIcon, label: 'Chat', route: '/live/chat' },
    { id: 'newfriends', icon: HeartIcon, label: 'New Friends', route: '/live/newfriends', isHighlight: true },
    { id: 'store', icon: ShoppingBagIcon, label: 'Store', route: '/live/store' },
    { id: 'settings', icon: CogIcon, label: 'Settings', route: '/live/settings' },
  ], []);

  const mobileNavItemClass = (isActive, isHighlight) => `
    relative p-3 flex flex-col items-center cursor-pointer
    transition-all duration-300
    ${currentTheme.text}
    ${isHighlight ? 'hover:scale-125 hover:shadow-xl' : currentTheme.hover}
    ${isActive ? (isHighlight ? `${currentTheme.highlight} text-white scale-125` : `${currentTheme.active} text-white`) : 'hover:scale-110'}
  `;

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`${API_URL}/api/users/profile/${username}`);
        const user = response.data.user;
        setUserData(user);
        setIsFollowing(user.followers?.includes(currentUser) || false);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch user profile');
      } finally {
        setLoading(false);
      }
    };

    const fetchBlocklist = async () => {
      if (!currentUser) return;
      try {
        const response = await axios.get(`${API_URL}/api/chat/get-blocklist/${currentUser}`);
        setBlocklist(response.data.blocklist || []);
      } catch (err) {
        console.error(`Failed to fetch blocklist for ${currentUser}: ${err.response?.data?.message || err.message}`);
      }
    };

    if (username) {
      fetchUserProfile();
      fetchBlocklist();
    }
  }, [username, currentUser]);

  // Handle clicks outside the menu to close it
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowMenu(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  const handleFollowClick = async () => {
    if (!currentUser) {
      setToaster({ message: 'Please log in to follow users', type: 'error', visible: true });
      setTimeout(() => setToaster({ ...toaster, visible: false }), 4000);
      navigate('/join-chat');
      return;
    }

    if (!username || typeof username !== 'string' || username.trim() === '') {
      setToaster({ message: 'Invalid user selected', type: 'error', visible: true });
      setTimeout(() => setToaster({ ...toaster, visible: false }), 4000);
      return;
    }

    const trimmedUsername = username.trim();

    try {
      const response = await axios.post(`${API_URL}/api/chat/add-friend`, {
        currentUser,
        username: trimmedUsername
      });
      setToaster({ message: response.data.message, type: 'success', visible: true });
      setUserData((prev) => ({
        ...prev,
        followers: [...(prev.followers || []), currentUser]
      }));
      setIsFollowing(true);
    } catch (err) {
      const message = err.response?.data?.message || 'Failed to follow user';
      setToaster({ message, type: 'error', visible: true });
      console.error(`Follow error for username=${trimmedUsername}, currentUser=${currentUser}: ${message}`);
    } finally {
      setTimeout(() => setToaster({ ...toaster, visible: false }), 4000);
    }
  };

  const handleUnfollow = async () => {
    try {
      const response = await axios.post(`${API_URL}/api/chat/unfriend`, {
        currentUser,
        username: username.trim()
      });
      setToaster({ message: response.data.message || 'Unfollowed successfully', type: 'success', visible: true });
      setUserData((prev) => ({
        ...prev,
        followers: prev.followers.filter((follower) => follower !== currentUser)
      }));
      setIsFollowing(false);
    } catch (err) {
      const message = err.response?.data?.message || 'Failed to unfollow user';
      setToaster({ message, type: 'error', visible: true });
    } finally {
      setShowMenu(false);
      setTimeout(() => setToaster({ ...toaster, visible: false }), 4000);
    }
  };

  const handleBlock = async () => {
    try {
      const response = await axios.post(`${API_URL}/api/chat/block-user`, {
        currentUser,
        username: username.trim()
      });
      setToaster({ message: response.data.message || 'User blocked successfully', type: 'success', visible: true });
      setUserData((prev) => ({
        ...prev,
        followers: prev.followers.filter((follower) => follower !== currentUser)
      }));
      setBlocklist((prev) => [...prev, username.trim()]);
      setIsFollowing(false);
    } catch (err) {
      const message = err.response?.data?.message || 'Failed to block user';
      setToaster({ message, type: 'error', visible: true });
    } finally {
      setShowMenu(false);
      setTimeout(() => setToaster({ ...toaster, visible: false }), 4000);
    }
  };

  const handleUnblock = async () => {
    try {
      const response = await axios.post(`${API_URL}/api/chat/unblock-user`, {
        currentUser,
        username: username.trim()
      });
      setToaster({ message: response.data.message || 'User unblocked successfully', type: 'success', visible: true });
      setBlocklist((prev) => prev.filter((user) => user !== username.trim()));
    } catch (err) {
      const message = err.response?.data?.message || 'Failed to unblock user';
      setToaster({ message, type: 'error', visible: true });
    } finally {
      setTimeout(() => setToaster({ ...toaster, visible: false }), 4000);
    }
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4, ease: 'easeOut' },
    },
  };

  const profilePicVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: { duration: 0.5, ease: 'easeOut' },
    },
  };

  const tabVariants = {
    active: { scale: 1.05, color: '#3b82f6' },
    inactive: { scale: 1, color: '#9ca3af' },
  };

  const underlineVariants = {
    hidden: { width: 0 },
    visible: { width: '100%', transition: { duration: 0.3 } },
  };

  const toasterVariants = {
    hidden: { y: -100, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.3, ease: 'easeOut' },
    },
    exit: {
      y: -100,
      opacity: 0,
      transition: { duration: 0.3, ease: 'easeIn' },
    },
  };

  const menuVariants = {
    hidden: { opacity: 0, scale: 0.8, x: '-50%' },
    visible: {
      opacity: 1,
      scale: 1,
      x: '-50%',
      transition: { duration: 0.2, ease: 'easeOut' },
    },
    exit: {
      opacity: 0,
      scale: 0.8,
      x: '-50%',
      transition: { duration: 0.2, ease: 'easeIn' },
    },
  };

  const isBlocked = blocklist.includes(username?.trim());

  if (loading) {
    return (
      <div className={`flex h-screen items-center justify-center ${isDarkTheme ? 'bg-gray-900' : 'bg-gray-100'}`}>
        <div className="flex space-x-2">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className={`w-3 h-3 rounded-full ${isDarkTheme ? 'bg-gray-400' : 'bg-gray-500'}`}
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.2 }}
            />
          ))}
        </div>
        <div className={`md:hidden fixed bottom-0 left-0 right-0 ${currentTheme.sidebar} shadow-lg flex justify-around items-center py-2 z-50`}>
          {mobileBottomItems.map((item) => (
            <a
              key={item.id}
              href={item.route}
              onClick={(e) => handleSectionChange(e, item.id)}
              className={mobileNavItemClass(activeSection === item.id, item.isHighlight)}
            >
              {activeSection === item.id && (
                <span 
                  className="absolute inset-0 bg-gradient-to-t from-white/20 to-transparent 
                  rounded-full opacity-30 transform scale-150 pointer-events-none"
                  style={{
                    backgroundImage: 'radial-gradient(circle at 50% 70%, rgba(255,255,255,0.25), transparent)',
                  }}
                />
              )}
              <item.icon 
                className={`relative z-10 w-6 h-6 transition-transform duration-300 
                  ${activeSection === item.id && !item.isHighlight ? 'scale-125' : ''} 
                  ${item.isHighlight ? 'w-7 h-7' : ''}`}
              />
            </a>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`min-h-screen ${isDarkTheme ? 'bg-gray-900 text-gray-100' : 'bg-gray-100 text-gray-800'} p-4`}>
        <div className="max-w-md mx-auto">
          <motion.div
            className="flex items-center mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <button
              onClick={handleBack}
              className={`p-2 rounded-full ${isDarkTheme ? 'text-gray-400 hover:bg-gray-800/50' : 'text-gray-500 hover:bg-gray-200/50'}`}
            >
              <ArrowLeftIcon className="w-5 h-5" />
            </button>
          </motion.div>
          <motion.div
            className="text-red-500 text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {error}
          </motion.div>
        </div>
        <div className={`md:hidden fixed bottom-0 left-0 right-0 ${currentTheme.sidebar} shadow-lg flex justify-around items-center py-2 z-50`}>
          {mobileBottomItems.map((item) => (
            <a
              key={item.id}
              href={item.route}
              onClick={(e) => handleSectionChange(e, item.id)}
              className={mobileNavItemClass(activeSection === item.id, item.isHighlight)}
            >
              {activeSection === item.id && (
                <span 
                  className="absolute inset-0 bg-gradient-to-t from-white/20 to-transparent 
                  rounded-full opacity-30 transform scale-150 pointer-events-none"
                  style={{
                    backgroundImage: 'radial-gradient(circle at 50% 70%, rgba(255,255,255,0.25), transparent)',
                  }}
                />
              )}
              <item.icon 
                className={`relative z-10 w-6 h-6 transition-transform duration-300 
                  ${activeSection === item.id && !item.isHighlight ? 'scale-125' : ''} 
                  ${item.isHighlight ? 'w-7 h-7' : ''}`}
              />
            </a>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${isDarkTheme ? 'bg-gray-900 text-gray-100' : 'bg-gray-100 text-gray-800'} font-sans`}>
      <AnimatePresence>
        {toaster.visible && (
          <motion.div
            className={`fixed top-5 left-1/2 transform -translate-x-1/2 z-50 pointer-events-none`}
            variants={toasterVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            <div
              className={`max-w-xs w-full px-4 py-2 rounded-lg shadow-lg pointer-events-auto ${
                toaster.type === 'success'
                  ? 'bg-green-500 text-white'
                  : 'bg-red-400/90 text-white backdrop-blur-sm'
              }`}
            >
              <p className="text-sm font-medium text-center">{toaster.message}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        className={`sticky top-0 z-10 ${isDarkTheme ? 'bg-gray-900/95' : 'bg-gray-100/95'} backdrop-blur-md border-b border-gray-700/50`}
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-md mx-auto flex items-center justify-between px-4 py-3">
          <button
            onClick={handleBack}
            className={`p-2 rounded-full ${isDarkTheme ? 'text-gray-400 hover:bg-gray-800/50' : 'text-gray-500 hover:bg-gray-200/50'} transition-all duration-200 hover:scale-110 hover:shadow-sm`}
          >
            <ArrowLeftIcon className="w-5 h-5" />
          </button>
          <h2 className="text-lg font-semibold tracking-tight">{userData?.username || 'Unknown'}</h2>
          <div className="w-10"></div>
        </div>
      </motion.div>

      <motion.div
        className="max-w-md mx-auto px-4 py-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="flex items-center mb-6">
          <motion.div className="relative mr-4" variants={profilePicVariants}>
            {userData?.profile_pic ? (
              <img
                src={`${API_URL}${userData.profile_pic}`}
                alt={userData.username}
                className="w-20 h-20 rounded-full object-cover shadow-sm ring-2 ring-offset-2 ring-gradient-to-r from-blue-500 to-purple-500"
                loading="lazy"
              />
            ) : (
              <div className="w-20 h-20 rounded-full bg-gray-700 flex items-center justify-center shadow-sm ring-2 ring-offset-2 ring-gradient-to-r from-blue-500 to-purple-500">
                <UserIcon className="w-8 h-8 text-gray-400" />
              </div>
            )}
          </motion.div>
          <motion.div className="flex-1" variants={itemVariants}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <h1 className="text-lg font-semibold tracking-tight mr-2">{userData?.username || 'Unknown'}</h1>
                {userData?.profile === 'public' ? (
                  <LockOpenIcon className="w-4 h-4 text-green-500" />
                ) : (
                  <LockClosedIcon className="w-4 h-4 text-red-500" />
                )}
              </div>
            </div>
            <div className="flex space-x-6 mb-4">
              {[
                { value: userData?.followers?.length || 0, label: 'Followers' },
                { value: userData?.following?.length || 0, label: 'Following' },
                { value: userData?.own_groups_count || 0, label: 'Groups' },
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  className="text-center"
                  variants={itemVariants}
                  whileHover={{ scale: 1.1, transition: { duration: 0.2 } }}
                >
                  <p className="font-semibold text-base">{stat.value}</p>
                  <p className="text-xs text-gray-400">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        <motion.div className="flex space-x-3 mb-6 relative" variants={itemVariants}>
          <div className="flex-1 relative">
            <motion.button
              onClick={() => {
                if (isBlocked) {
                  handleUnblock();
                } else if (isFollowing) {
                  setShowMenu(!showMenu);
                } else {
                  handleFollowClick();
                }
              }}
              className={`w-full py-2 rounded-full font-medium text-sm transition-all duration-200 shadow-sm hover:shadow-md hover:scale-105 ${
                isBlocked
                  ? 'text-white bg-red-500 hover:bg-red-600'
                  : isFollowing
                  ? `bg-transparent border border-gray-600 ${isDarkTheme ? 'text-gray-100 hover:bg-gray-800/50' : 'text-gray-800 hover:bg-gray-200/50'}`
                  : 'text-white bg-gradient-to-l from-red-500 to-pink-500 hover:opacity-90'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {isBlocked ? 'Unblock' : isFollowing ? 'Following' : 'Follow'}
            </motion.button>
            <AnimatePresence>
              {showMenu && !isBlocked && (
                <motion.div
                  ref={menuRef}
                  className={`absolute left-full top-1/2 transform -translate-y-1/2 ml-2 z-50 w-40 rounded-lg shadow-lg overflow-hidden ${isDarkTheme ? 'bg-gray-800 text-gray-100' : 'bg-white text-gray-800'}`}
                  variants={menuVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                >
                  <button
                    onClick={handleUnfollow}
                    className={`flex items-center w-full px-4 py-2 text-sm hover:bg-opacity-10 hover:bg-gray-500 transition-colors duration-150 ${isDarkTheme ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}
                  >
                    <UserMinusIcon className="w-4 h-4 mr-2" />
                    Unfollow
                  </button>
                  <button
                    onClick={handleBlock}
                    className={`flex items-center w-full px-4 py-2 text-sm hover:bg-opacity-10 hover:bg-gray-500 transition-colors duration-150 ${isDarkTheme ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}
                  >
                    <SlashIcon className="w-4 h-4 mr-2" />
                    Block
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <motion.button
            className={`flex-1 py-2 rounded-full font-medium text-sm border border-gray-600 ${isDarkTheme ? 'text-gray-100 hover:bg-gray-800/50' : 'text-gray-800 hover:bg-gray-200/50'} transition-all duration-200 shadow-sm hover:shadow-md hover:scale-105`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Message
          </motion.button>
        </motion.div>

        <motion.div className="mb-6" variants={itemVariants}>
          <div className="flex items-center mb-2">
            <UserIcon className="w-4 h-4 mr-1 text-gray-400" />
            <p className="font-medium text-base tracking-tight">{userData?.name || userData?.username}</p>
          </div>
          <div className="flex items-start mb-2">
            <InformationCircleIcon className="w-4 h-4 mr-1 text-gray-400 mt-1" />
            <p className="text-sm text-gray-400 whitespace-pre-wrap leading-relaxed">
              {userData?.bio || 'No bio available'}
            </p>
          </div>
          {userData?.location && (
            <div className="flex items-center mt-2">
              <MapPinIcon className="w-4 h-4 mr-1 text-gray-400" />
              <p className="text-sm text-gray-400">{userData.location}</p>
            </div>
          )}
        </motion.div>

        <motion.div
          className="grid grid-cols-3 gap-4 mb-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {userData?.age && (
            <motion.div variants={itemVariants} whileHover={{ scale: 1.05 }}>
              <div className="flex items-center">
                <CalendarIcon className="w-4 h-4 mr-1 text-gray-400" />
                <p className="text-xs text-gray-400">Age</p>
              </div>
              <p className="font-medium text-sm">{userData.age}</p>
            </motion.div>
          )}
          {userData?.gender && (
            <motion.div variants={itemVariants} whileHover={{ scale: 1.05 }}>
              <div className="flex items-center">
                <UserIcon className="w-4 h-4 mr-1 text-gray-400" />
                <p className="text-xs text-gray-400">Gender</p>
              </div>
              <p className="font-medium text-sm">{userData.gender}</p>
            </motion.div>
          )}
          {userData?.level && (
            <motion.div variants={itemVariants} whileHover={{ scale: 1.05 }}>
              <div className="flex items-center">
                <StarIcon className="w-4 h-4 mr-1 text-gray-400" />
                <p className="text-xs text-gray-400">Level</p>
              </div>
              <p className="font-medium text-sm">{userData.level}</p>
            </motion.div>
          )}
        </motion.div>
      </motion.div>

      <div className={`md:hidden fixed bottom-0 left-0 right-0 ${currentTheme.sidebar} shadow-lg flex justify-around items-center py-2 z-50`}>
        {mobileBottomItems.map((item) => (
          <a
            key={item.id}
            href={item.route}
            onClick={(e) => handleSectionChange(e, item.id)}
            className={mobileNavItemClass(activeSection === item.id, item.isHighlight)}
          >
            {activeSection === item.id && (
              <span 
                className="absolute inset-0 bg-gradient-to-t from-white/20 to-transparent 
                rounded-full opacity-30 transform scale-150 pointer-events-none"
                style={{
                  backgroundImage: 'radial-gradient(circle at 50% 70%, rgba(255,255,255,0.25), transparent)',
                }}
              />
            )}
            <item.icon 
              className={`relative z-10 w-6 h-6 transition-transform duration-300 
                ${activeSection === item.id && !item.isHighlight ? 'scale-125' : ''} 
                ${item.isHighlight ? 'w-7 h-7' : ''}`}
            />
          </a>
        ))}
      </div>
    </div>
  );
};

export default Profile;