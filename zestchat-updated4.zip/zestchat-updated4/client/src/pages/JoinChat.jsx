import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

function JoinChat() {
  const [activeCard, setActiveCard] = useState(null);
  const [registerError, setRegisterError] = useState("");
  const [registerSuccess, setRegisterSuccess] = useState("");
  const [loginError, setLoginError] = useState("");
  const [loginSuccess, setLoginSuccess] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [gender, setGender] = useState("");
  const [usernameError, setUsernameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [genderError, setGenderError] = useState("");
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginUsernameError, setLoginUsernameError] = useState("");
  const [loginPasswordError, setLoginPasswordError] = useState("");
  const [loading, setLoading] = useState(false); // New loading state
  const navigate = useNavigate();

  useEffect(() => {
    const userData = JSON.parse(localStorage.getItem("zestchat-user"));
    if (userData && userData.expiry > Date.now()) {
      navigate("/live");
    }
  }, [navigate]);

  const handleCardChange = (card) => {
    setActiveCard(card === activeCard ? null : card);
    setRegisterError("");
    setRegisterSuccess("");
    setLoginError("");
    setLoginSuccess("");
    setUsername("");
    setEmail("");
    setPassword("");
    setGender("");
    setUsernameError("");
    setEmailError("");
    setPasswordError("");
    setGenderError("");
    setLoginUsername("");
    setLoginPassword("");
    setLoginUsernameError("");
    setLoginPasswordError("");
    setLoading(false); // Reset loading
  };

  const validateUsername = (value) => {
    const regex = /^[a-zA-Z0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]{3,25}$/;
    if (!regex.test(value)) {
      setUsernameError(
        "Username must be 3-25 characters and can include letters, numbers, and special characters"
      );
      return false;
    }
    setUsernameError("");
    return true;
  };

  const validateEmail = (value) => {
    const regex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    if (!regex.test(value)) {
      setEmailError("Email must end with @gmail.com");
      return false;
    }
    setEmailError("");
    return true;
  };

  const validatePassword = (value) => {
    const letterCount = (value.match(/[a-zA-Z]/g) || []).length;
    const numberCount = (value.match(/[0-9]/g) || []).length;
    const regex = /^[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?a-zA-Z0-9]{5,15}$/;
    if (!regex.test(value)) {
      setPasswordError("Password must be 5-15 characters");
      return false;
    } else if (letterCount < 4 || numberCount < 2) {
      setPasswordError("Password must have at least 4 letters and 2 numbers");
      return false;
    }
    setPasswordError("");
    return true;
  };

  const validateGender = (value) => {
    if (!value) {
      setGenderError("Gender is required");
      return false;
    }
    setGenderError("");
    return true;
  };

  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    const usernameValid = validateUsername(username);
    const emailValid = validateEmail(email);
    const passwordValid = validatePassword(password);
    const genderValid = validateGender(gender);

    if (!usernameValid || !emailValid || !passwordValid || !genderValid) {
      setRegisterError("Please fix the errors above");
      return;
    }

    setLoading(true); // Start loader
    try {
      const response = await fetch("http://localhost:5000/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, email, password, gender }),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Registration failed");
      }

      const expiryTime = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
      const userData = {
        ...data.user, // Spread full user data (id, username, email, gender)
        token: data.token, // Include token if provided by backend
        expiry: expiryTime,
      };
      localStorage.setItem("zestchat-user", JSON.stringify(userData));

      setRegisterSuccess(data.message);
      setRegisterError("");
      setUsername("");
      setEmail("");
      setPassword("");
      setGender("");
      navigate("/live"); // Loader will disappear once navigation completes
    } catch (error) {
      setRegisterError(error.message);
      setRegisterSuccess("");
      if (error.message.includes("Username")) {
        setUsernameError(error.message);
      } else if (error.message.includes("email")) {
        setEmailError(error.message);
      }
    } finally {
      setLoading(false); // Stop loader
    }
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setLoginUsernameError("");
    setLoginPasswordError("");
    setLoginError("");
    setLoginSuccess("");

    if (!loginUsername || !loginPassword) {
      setLoginError("Username and password are required");
      return;
    }

    setLoading(true); // Start loader
    try {
      const response = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: loginUsername, password: loginPassword }),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Login failed");
      }

      const expiryTime = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
      const userData = {
        ...data.user, // Spread full user data (id, username, email, gender)
        token: data.token, // Include token
        expiry: expiryTime,
      };
      localStorage.setItem("zestchat-user", JSON.stringify(userData));

      setLoginSuccess(data.message);
      setLoginError("");
      setLoginUsername("");
      setLoginPassword("");
      navigate("/live"); // Loader will disappear once navigation completes
    } catch (error) {
      setLoginError(error.message);
      setLoginSuccess("");
      if (error.message.includes("username") || error.message.includes("password")) {
        setLoginUsernameError("Invalid username or password");
        setLoginPasswordError("Invalid username or password");
      }
    } finally {
      setLoading(false); // Stop loader
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("zestchat-user");
    setActiveCard(null);
    navigate("/");
  };

  return (
    <div className="flex-1 flex items-center justify-center py-6 sm:py-10 md:py-20 bg-gray-100 min-h-screen relative">
      {/* Loader */}
      {loading && (
        <div className="fixed inset-0 flex justify-center items-center z-50 bg-black bg-opacity-50">
          <div className="flex space-x-2">
            <div
              className="w-4 h-4 rounded-full animate-bounce bg-blue-600"
              style={{ animationDelay: "0s" }}
            ></div>
            <div
              className="w-4 h-4 rounded-full animate-bounce bg-blue-600"
              style={{ animationDelay: "0.2s" }}
            ></div>
            <div
              className="w-4 h-4 rounded-full animate-bounce bg-blue-600"
              style={{ animationDelay: "0.4s" }}
            ></div>
          </div>
        </div>
      )}

      {!activeCard && (
        <div className="bg-gradient-to-br from-purple-900 to-black p-4 sm:p-6 rounded-xl shadow-lg backdrop-blur-md bg-opacity-80 w-full max-w-xs sm:max-w-sm md:max-w-md text-white">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center">
            Join ZestChat
          </h2>
          <div className="space-y-3 sm:space-y-4">
            <button
              onClick={() => handleCardChange("login")}
              className="w-full bg-white text-blue-800 py-2 sm:py-3 rounded-lg font-semibold hover:bg-blue-100 transition duration-300 text-sm sm:text-base"
            >
              Login
            </button>
            <button
              onClick={() => handleCardChange("register")}
              className="w-full bg-white text-blue-800 py-2 sm:py-3 rounded-lg font-semibold hover:bg-blue-100 transition duration-300 text-sm sm:text-base"
            >
              Register
            </button>
            <button
              onClick={() => handleCardChange("guest")}
              className="w-full bg-white text-blue-800 py-2 sm:py-3 rounded-lg font-semibold hover:bg-blue-100 transition duration-300 text-sm sm:text-base"
            >
              Continue as Guest
            </button>
          </div>
        </div>
      )}

      {activeCard === "register" && (
        <div className="bg-gradient-to-br from-purple-900 to-black p-4 sm:p-6 rounded-xl shadow-lg backdrop-blur-md bg-opacity-80 w-full max-w-xs sm:max-w-sm md:max-w-md text-white">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center">
            Register
          </h2>
          <form className="space-y-3 sm:space-y-4" onSubmit={handleRegisterSubmit}>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1">
                Username
              </label>
              <input
                name="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-2 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-200 text-sm sm:text-base"
                placeholder="Enter your username"
                required
              />
              {usernameError && (
                <p className="text-red-200 text-xs sm:text-sm mt-1">{usernameError}</p>
              )}
            </div>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1">
                Email
              </label>
              <input
                name="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-200 text-sm sm:text-base"
                placeholder="Enter your email"
                required
              />
              {emailError && (
                <p className="text-red-200 text-xs sm:text-sm mt-1">{emailError}</p>
              )}
            </div>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1">
                Password
              </label>
              <input
                name="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-2 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-200 text-sm sm:text-base"
                placeholder="Enter your password"
                required
              />
              {passwordError && (
                <p className="text-red-200 text-xs sm:text-sm mt-1">{passwordError}</p>
              )}
            </div>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1">
                Gender
              </label>
              <select
                name="gender"
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="w-full p-2 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-200 text-sm sm:text-base"
                required
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
              {genderError && (
                <p className="text-red-200 text-xs sm:text-sm mt-1">{genderError}</p>
              )}
            </div>
            {registerError && (
              <p className="text-red-200 text-xs sm:text-sm">{registerError}</p>
            )}
            {registerSuccess && (
              <p className="text-green-200 text-xs sm:text-sm">{registerSuccess}</p>
            )}
            <button
              type="submit"
              className="w-full bg-white text-blue-800 py-2 sm:py-3 rounded-lg font-semibold hover:bg-blue-100 transition duration-300 text-sm sm:text-base"
              disabled={loading} // Disable button during loading
            >
              Register
            </button>
          </form>
          <button
            onClick={() => setActiveCard(null)}
            className="mt-3 sm:mt-4 text-blue-200 hover:text-white transition duration-300 text-xs sm:text-sm"
          >
            Back
          </button>
        </div>
      )}

      {activeCard === "login" && (
        <div className="bg-gradient-to-br from-purple-900 to-black p-4 sm:p-6 rounded-xl shadow-lg backdrop-blur-md bg-opacity-80 w-full max-w-xs sm:max-w-sm md:max-w-md text-white">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center">
            Login
          </h2>
          <form className="space-y-3 sm:space-y-4" onSubmit={handleLoginSubmit}>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1">
                Username
              </label>
              <input
                type="text"
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                className="w-full p-2 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-200 text-sm sm:text-base"
                placeholder="Enter your username"
                required
              />
              {loginUsernameError && (
                <p className="text-red-200 text-xs sm:text-sm mt-1">{loginUsernameError}</p>
              )}
            </div>
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1">
                Password
              </label>
              <input
                type="password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full p-2 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-200 text-sm sm:text-base"
                placeholder="Enter your password"
                required
              />

            </div>
            {loginError && (
              <p className="text-red-200 text-xs sm:text-sm">{loginError}</p>
            )}
            {loginSuccess && (
              <p className="text-green-200 text-xs sm:text-sm">{loginSuccess}</p>
            )}
            <button
              type="submit"
              className="w-full bg-white text-blue-800 py-2 sm:py-3 rounded-lg font-semibold hover:bg-blue-100 transition duration-300 text-sm sm:text-base"
              disabled={loading} // Disable button during loading
            >
              Login
            </button>
            <button
              type="button"
              onClick={() => handleCardChange("forgot")}
              className="w-full text-blue-200 hover:text-white transition duration-300 text-xs sm:text-sm"
            >
              Forgot Password?
            </button>
          </form>
          <button
            onClick={() => setActiveCard(null)}
            className="mt-3 sm:mt-4 text-blue-200 hover:text-white transition duration-300 text-xs sm:text-sm"
          >
            Back
          </button>
        </div>
      )}

      {activeCard === "forgot" && (
        <div className="bg-gradient-to-br from-purple-900 to-black p-4 sm:p-6 rounded-xl shadow-lg backdrop-blur-md bg-opacity-80 w-full max-w-xs sm:max-w-sm md:max-w-md text-white">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center">
            Forgot Password
          </h2>
          <form className="space-y-3 sm:space-y-4">
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1">
                Email
              </label>
              <input
                type="email"
                className="w-full p-2 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-200 text-sm sm:text-base"
                placeholder="Enter your email"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-white text-blue-800 py-2 sm:py-3 rounded-lg font-semibold hover:bg-blue-100 transition duration-300 text-sm sm:text-base"
            >
              Reset Password
            </button>
          </form>
          <button
            onClick={() => setActiveCard("login")}
            className="mt-3 sm:mt-4 text-blue-200 hover:text-white transition duration-300 text-xs sm:text-sm"
          >
            Back to Login
          </button>
        </div>
      )}

      {activeCard === "guest" && (
        <div className="bg-gradient-to-br from-purple-900 to-black p-4 sm:p-6 rounded-xl shadow-lg backdrop-blur-md bg-opacity-80 w-full max-w-xs sm:max-w-sm md:max-w-md text-white">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center">
            Continue as Guest
          </h2>
          <form className="space-y-3 sm:space-y-4">
            <div>
              <label className="block text-xs sm:text-sm font-medium mb-1">
                Guest Name
              </label>
              <input
                type="text"
                className="w-full p-2 rounded-lg bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-200 text-sm sm:text-base"
                placeholder="Enter a guest name"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-white text-blue-800 py-2 sm:py-3 rounded-lg font-semibold hover:bg-blue-100 transition duration-300 text-sm sm:text-base"
            >
              Join as Guest
            </button>
          </form>
          <button
            onClick={() => setActiveCard(null)}
            className="mt-3 sm:mt-4 text-blue-200 hover:text-white transition duration-300 text-xs sm:text-sm"
          >
            Back
          </button>
        </div>
      )}
    </div>
  );
}

export default JoinChat;