import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Home() {
  const navigate = useNavigate();

  // Check localStorage on component mount
  useEffect(() => {
    const user = localStorage.getItem("zestchat-user");
    if (user) {
      navigate("/live");
    }
  }, [navigate]); // Dependency array includes navigate to satisfy useEffect rules

  return (
    <div className="flex-1 flex flex-col">
      <section className="flex-1 flex items-center justify-center py-20 bg-gray-100">
        <div className="text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold text-gray-800 mb-4">
            Welcome to ZestChat
          </h2>
          <p className="text-lg md:text-xl text-gray-600 mb-8">
            Connect with friends and strangers in real-time. Start chatting now!
          </p>
          <Link to="/join-chat">
            <button className="bg-blue-600 text-white px-6 py-3 rounded-full font-semibold hover:bg-blue-700 transition">
              Join the Chat
            </button>
          </Link>
        </div>
      </section>
      <section className="bg-white py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl font-bold text-gray-800 mb-6">About Us</h3>
          <p className="text-gray-600">
            ZestChat is a simple, fast, and fun way to communicate with people around the world. Built with modern technologies, it offers real-time messaging with a sleek interface.
          </p>
        </div>
      </section>
    </div>
  );
}

export default Home;