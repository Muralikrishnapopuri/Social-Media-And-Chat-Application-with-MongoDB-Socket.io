import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { 
  Home,
  MessageSquare,
  ShoppingBag,
  Heart,
  Menu,
  Bell,
  Share2,
  LogOut,
  Moon,
  Sun,
  Settings as SettingsIcon,
  X
} from 'react-feather';
import { useNavigate, useLocation, Routes, Route } from 'react-router-dom';
import Groups from '../components/Groups';
import GroupChat from '../components/GroupChat';
import Chat from '../components/Chat';
import Store from '../components/Store';
import Settings from '../components/SettingsPage';
import Notifications from '../components/Notifications';
import Profile from '../components/Profile';
import Share from '../components/Share';
import NewFriends from '../components/NewFriends';

const Live = ({ extraContent }) => {
  const [activeSection, setActiveSection] = useState('home');
  const [isDarkTheme, setIsDarkTheme] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [username, setUsername] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  const isGroupChatRoute = location.pathname.startsWith('/live/group');
  const themes = useMemo(() => ({
    light: {
      sidebar: 'bg-gradient-to-b from-gray-50 to-gray-100',
      content: 'bg-gradient-to-br from-gray-100 via-gray-200 to-gray-300',
      text: 'text-black-100',
      hover: 'hover:bg-opacity-30 hover:bg-sky-900',
      active: 'bg-gradient-to-l from-red-500 to-pink-500',
      highlight: 'bg-gradient-to-l from-purple-500 to-indigo-500'
    },
    dark: {
      sidebar: 'bg-gradient-to-b from-gray-900 to-black',
      content: 'bg-gradient-to-br from-gray-700 via-gray-800 to-gray-900',
      text: 'text-white',
      hover: 'hover:bg-opacity-10 hover:bg-sky-100',
      active: 'bg-gradient-to-l from-red-500 to-pink-500',
      highlight: 'bg-gradient-to-l from-purple-600 to-indigo-600'
    }
  }), []);

  const currentTheme = isDarkTheme ? themes.dark : themes.light;
  const desktopMenuItems = useMemo(() => [
    { id: 'home', icon: Home, label: 'Home', route: '/live' },
    { id: 'chat', icon: MessageSquare, label: 'Chat', route: '/live/chat' },
    { id: 'newfriends', icon: Heart, label: 'New Friends', route: '/live/newfriends', isHighlight: true },
    { id: 'settings', icon: SettingsIcon, label: 'Settings', route: '/live/settings' },
    { id: 'store', icon: ShoppingBag, label: 'Store', route: '/live/store' },
    { id: 'share', icon: Share2, label: 'Share', route: '/live/share' },
    { id: 'logout', icon: LogOut, label: 'Logout', route: '/logout' },
  ], []);

  const mobileBottomItems = useMemo(() => [
    { id: 'home', icon: Home, label: 'Home', route: '/live' },
    { id: 'chat', icon: MessageSquare, label: 'Chat', route: '/live/chat' },
    { id: 'newfriends', icon: Heart, label: 'New Friends', route: '/live/newfriends', isHighlight: true },
    { id: 'store', icon: ShoppingBag, label: 'Store', route: '/live/store' },
    { id: 'settings', icon: SettingsIcon, label: 'Settings', route: '/live/settings' },
  ], []);

  const mobileMenuItems = useMemo(() => [
    { id: 'share', icon: Share2, label: 'Share', route: '/live/share' },
    { id: 'theme', isThemeToggle: true },
    { id: 'logout', icon: LogOut, label: 'Logout', route: '/logout' },
  ], []);

  useEffect(() => {
    const verifyUser = async () => {
      try {
        const storedUser = JSON.parse(localStorage.getItem('zestchat-user') || '{}');
        const storedTheme = localStorage.getItem('zestchat-theme');
        
        if (!storedUser.username || !storedUser.token) {
          navigate('/');
          return;
        }

        const response = await fetch('http://localhost:5000/api/auth/verify-token', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${storedUser.token}`,
            'Content-Type': 'application/json',
          },
        });

        if (!response.ok) {
          localStorage.removeItem('zestchat-user');
          navigate('/');
          return;
        }

        const data = await response.json();
        if (!data.success || !data.user) {
          localStorage.removeItem('zestchat-user');
          navigate('/');
          return;
        }
        localStorage.setItem('zestchat-user', JSON.stringify({
          ...storedUser,
          token: data.token
        }));
        setUsername(data.user.username);

        if (storedTheme) {
          setIsDarkTheme(storedTheme === 'dark');
        }
      } catch (error) {
        console.error('User verification failed:', error);
        localStorage.removeItem('zestchat-user');
        navigate('/');
      } finally {
        setIsLoading(false);
      }
    };

    verifyUser();
  }, [navigate]);

  const handleSectionChange = useCallback((e, id) => {
    e.preventDefault();
    if (id !== 'logout') {
      setActiveSection(id);
      setIsMenuOpen(false);
      navigate(`/live${id === 'home' ? '' : `/${id}`}`);
    } else {
      localStorage.removeItem('zestchat-user');
      localStorage.removeItem('zestchat-theme');
      setIsDarkTheme(false);
      setIsMenuOpen(false);
      setUsername('');
      navigate('/join-chat');
    }
  }, [navigate]);

  const handleGroupClick = useCallback((groupId) => {
    setActiveSection('group');
    navigate(`/live/group/${groupId}`);
  }, [navigate]);

  const toggleTheme = useCallback(() => {
    setIsDarkTheme(prev => {
      const newTheme = !prev;
      localStorage.setItem('zestchat-theme', newTheme ? 'dark' : 'light');
      return newTheme;
    });
  }, []);

  const toggleMenu = useCallback(() => {
    setIsMenuOpen(prev => !prev);
  }, []);

  const navItemClass = (isActive, isHighlight) => `
    p-4 flex justify-center items-center cursor-pointer
    transition-all duration-300 backdrop-blur-sm
    ${currentTheme.text}
    ${isHighlight ? 'hover:scale-100 hover:shadow-x2 ' : currentTheme.hover}
    ${isActive ? (isHighlight ? `${currentTheme.highlight} text-white scale-50` : `${currentTheme.active} text-white`) : ''}
    ${isDarkTheme ? 'hover:shadow-lg' : 'hover:shadow-md'}
  `;

  const mobileNavItemClass = (isActive, isHighlight) => `
    relative p-3 flex flex-col items-center cursor-pointer
    transition-all duration-300
    ${currentTheme.text}
    ${isHighlight ? 'hover:scale-125 hover:shadow-xl' : currentTheme.hover}
    ${isActive ? (isHighlight ? `${currentTheme.highlight} text-white scale-125` : `${currentTheme.active} text-white`) : 'hover:scale-110'}
  `;

  const renderContent = () => {
    switch (activeSection) {
      case 'home':
        return <Groups onGroupClick={handleGroupClick} />;
      case 'chat':
        return <Chat />;
      case 'store':
        return <Store />;
      case 'settings':
        return <Settings />;
      case 'notifications':
        return <Notifications />;
      case 'profile':
        return <Profile />;
      case 'share':
        return <Share />;
      case 'newfriends':
        return <NewFriends />;
      default:
        return <Groups onGroupClick={handleGroupClick} />;
    }
  };

  return (
    <div className="flex h-screen flex-col md:flex-row">
      {/* Mobile top navbar - hidden on group chat */}
      {!isGroupChatRoute && (
        <div className={`md:hidden fixed top-0 left-0 right-0 z-50 ${currentTheme.sidebar} shadow-lg flex justify-between items-center p-2`}>
          <div className="flex items-center gap-2">
            <span className={currentTheme.text}>{username || 'Guest'}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => handleSectionChange(e, 'notifications')}
              className={navItemClass(activeSection === 'notifications', false)}
            >
              <Bell size={20} />
            </button>
            <button onClick={toggleMenu} className={navItemClass(false, false)}>
              <Menu size={20} />
            </button>
          </div>
        </div>
      )}

      {/* Desktop sidebar - always visible */}
      <div className={`hidden md:flex md:flex-col md:w-16 lg:w-20 ${currentTheme.sidebar} shadow-lg`}>
        {desktopMenuItems.map((item) => (
          <a
            key={item.id}
            href={item.route}
            onClick={(e) => handleSectionChange(e, item.id)}
            className={navItemClass(activeSection === item.id, item.isHighlight)}
          >
            <item.icon size={24} />
          </a>
        ))}
        <button onClick={toggleTheme} className={navItemClass(false, false)}>
          {isDarkTheme ? <Sun size={24} /> : <Moon size={24} />}
        </button>
      </div>

      {/* Main content area */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Desktop: Groups column - visible only on group chat route */}
        {isGroupChatRoute ? (
          <div className={`hidden md:block md:w-3/5 lg:w-3/5 ${currentTheme.content} overflow-y-auto`}>
            <Groups onGroupClick={handleGroupClick} />
          </div>
        ) : null}

        {/* Main content - adjusts width based on group chat route */}
        <div className={`flex-1 overflow-y-auto ${currentTheme.content} ${isGroupChatRoute ? 'md:w-2/5 lg:w-2/5' : 'md:pt-0 pt-12'}`}>
          {isGroupChatRoute ? (
            <Routes>
              <Route 
                path="/group/:groupId" 
                element={<GroupChat activeSection={activeSection} handleSectionChange={handleSectionChange} />} 
              />
            </Routes>
          ) : (
            renderContent()
          )}
        </div>
      </div>

      {/* Mobile bottom navbar - hidden on group chat */}
      {!isGroupChatRoute && (
        <div className={`md:hidden fixed bottom-0 left-0 right-0 ${currentTheme.sidebar} shadow-lg flex justify-around items-center py-2`}>
          {mobileBottomItems.map((item) => (
            <a
              key={item.id}
              href={item.route}
              onClick={(e) => handleSectionChange(e, item.id)}
              className={mobileNavItemClass(activeSection === item.id, item.isHighlight)}
            >
              {activeSection === item.id && (
                <span 
                  className="absolute inset-0 bg-gradient-to-t from-white/20 to-transparent 
                  rounded-full opacity-30 transform scale-150 pointer-events-none"
                  style={{
                    backgroundImage: 'radial-gradient(circle at 50% 70%, rgba(255,255,255,0.25), transparent)',
                  }}
                />
              )}
              <item.icon 
                size={item.isHighlight ? 28 : 22}
                className={`relative z-10 transition-transform duration-300 
                  ${activeSection === item.id && !item.isHighlight ? 'scale-125' : ''}`}
              />
            </a>
          ))}
        </div>
      )}

      {/* Mobile side menu - hidden on group chat */}
      {!isGroupChatRoute && (
        <div
          className={`md:hidden fixed top-0 right-0 h-full w-64 ${currentTheme.sidebar} shadow-lg z-50
            transform transition-transform duration-300 ease-in-out
            ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}
        >
          <div className="relative flex flex-col h-full">
            <button
              onClick={toggleMenu}
              className={`absolute top-4 right-4 p-2 ${currentTheme.text} ${currentTheme.hover}`}
            >
              <X size={24} />
            </button>
            <div className="flex flex-col pt-16">
              {mobileMenuItems.map((item) => (
                item.isThemeToggle ? (
                  <button
                    key={item.id}
                    onClick={toggleTheme}
                    className={`flex items-center gap-2 p-4 ${currentTheme.text} ${currentTheme.hover}`}
                  >
                    {isDarkTheme ? <Sun size={20} /> : <Moon size={20} />}
                    <span>{isDarkTheme ? 'Light Theme' : 'Dark Theme'}</span>
                  </button>
                ) : (
                  <a
                    key={item.id}
                    href={item.route}
                    onClick={(e) => handleSectionChange(e, item.id)}
                    className={`flex items-center gap-2 p-4 ${currentTheme.text} ${currentTheme.hover}
                      ${activeSection === item.id ? `${currentTheme.active} text-white` : ''}`}
                  >
                    <item.icon size={20} />
                    <span>{item.label}</span>
                  </a>
                )
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Live;