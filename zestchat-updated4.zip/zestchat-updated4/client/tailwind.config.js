module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        magenta: {
          100: '#F5CCFF', // Very light magenta
          200: '#F1A9FF', // Light magenta
          300: '#EC85FF', // Vibrant light magenta
          400: '#E066FF', // Medium magenta
          500: '#CC33FF', // Strong magenta
          600: '#B800E6', // Deep magenta
          700: '#A300CC', // Dark magenta
          800: '#8F00B3', // Very dark magenta
          900: '#7A0099', // Deepest magenta
        },
        pink: {
          400: '#FF66B2', // Vibrant pink
          700: '#CC0066', // Softer dark pink
        }
      }
    },
  },
  plugins: [],
}