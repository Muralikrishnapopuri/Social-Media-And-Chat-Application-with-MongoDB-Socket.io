require("dotenv").config();
const { Pool } = require("pg");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

async function initializeDatabase() {
  let client;
  try {
    client = await pool.connect();
    console.log("Database connected successfully");

    // Create Users table with additional columns
    const createUsersTableQuery = `
      CREATE TABLE IF NOT EXISTS users (
       id SERIAL PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  gender VARCHAR(50) NOT NULL,
  level VARCHAR(50) NOT NULL DEFAULT 'Bronze',
  own_groups_count INTEGER DEFAULT 0,
  age VARCHAR(50) DEFAULT 'none',
  bio TEXT DEFAULT 'Bio not mentioned yet',
  location VARCHAR(255) DEFAULT 'none',
  profile_pic VARCHAR(255),
  followers TEXT[] DEFAULT '{}',
  following TEXT[] DEFAULT '{}',
  blocklist TEXT[] DEFAULT '{}',
  profile VARCHAR(50) DEFAULT 'public'
      );
    `;
    await client.query(createUsersTableQuery);
    console.log("Users table ensured (created if not exists)");

    // Create Groups table (unchanged)
    const createGroupsTableQuery = `
      CREATE TABLE IF NOT EXISTS groups (
        group_id SERIAL PRIMARY KEY,
        group_title VARCHAR(255) NOT NULL UNIQUE,
        group_pic VARCHAR(255),
        description TEXT,
        total_users INTEGER DEFAULT 0,
        blocklist TEXT[] DEFAULT '{}',
        users_array TEXT[] DEFAULT '{}',
        owner VARCHAR(255) NOT NULL,
        admins TEXT[] DEFAULT '{}',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;
    await client.query(createGroupsTableQuery);
    console.log("Groups table ensured (created if not exists)");

    // Create Levels table (unchanged)
    const createLevelsTableQuery = `
      CREATE TABLE IF NOT EXISTS levels (
        level VARCHAR(50) PRIMARY KEY,
        own_groups_count INTEGER NOT NULL,
        text_style VARCHAR(50) NOT NULL
      );
    `;
    await client.query(createLevelsTableQuery);
    console.log("Levels table ensured (created if not exists)");

    // Insert initial data into Levels table (unchanged)
    const insertLevelsDataQuery = `
      INSERT INTO levels (level, own_groups_count, text_style)
      VALUES
        ('Bronze', 1, 'style-1'),
        ('Silver', 3, 'style-2'),
        ('Gold', 6, 'style-3'),
        ('Platinum', 12, 'style-4'),
        ('Diamond', 20, 'style-5')
      ON CONFLICT (level) DO NOTHING;
    `;
    await client.query(insertLevelsDataQuery);
    console.log("Levels data ensured (inserted if not exists)");
  } catch (error) {
    console.error("Database connection failed:", error.message);
    throw error;
  } finally {
    if (client) client.release();
  }
}

initializeDatabase().catch((err) => {
  console.error("Failed to initialize database:", err);
  process.exit(1);
});

module.exports = pool;
