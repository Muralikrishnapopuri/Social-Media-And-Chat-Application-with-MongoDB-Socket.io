const express = require('express');
const pool = require('../config/db');
const router = express.Router();

// Add current user to another user's followers array
router.post('/add-friend', async (req, res) => {
  const { currentUser, username } = req.body;

  try {
    // Validate input
    if (!username || typeof username !== 'string' || username.trim() === '') {
      return res.status(400).json({ message: 'Invalid target username provided' });
    }
    if (!currentUser || typeof currentUser !== 'string' || currentUser.trim() === '') {
      return res.status(400).json({ message: 'Invalid current user provided' });
    }

    // Normalize usernames
    const normalizedUsername = username.trim();
    const normalizedCurrentUser = currentUser.trim();

    // Check if target user exists
    const checkQuery = `SELECT username, followers FROM users WHERE LOWER(username) = LOWER($1)`;
    const checkResult = await pool.query(checkQuery, [normalizedUsername]);

    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Target user not found' });
    }

    const targetUser = checkResult.rows[0].username;
    const { followers } = checkResult.rows[0];

    // Check if current user exists
    const currentUserCheckQuery = `SELECT username FROM users WHERE LOWER(username) = LOWER($1)`;
    const currentUserCheckResult = await pool.query(currentUserCheckQuery, [normalizedCurrentUser]);

    if (currentUserCheckResult.rows.length === 0) {
      return res.status(404).json({ message: 'Current user not found' });
    }

    // Prevent self-following
    if (targetUser.toLowerCase() === normalizedCurrentUser.toLowerCase()) {
      return res.status(400).json({ message: 'Cannot follow yourself' });
    }

    // Check if already following
    if (followers && followers.includes(normalizedCurrentUser)) {
      return res.status(400).json({ message: 'Already following this user' });
    }

    // Update followers array
    const updateQuery = `
      UPDATE users 
      SET 
        followers = COALESCE(followers, '{}') || $1
      WHERE username = $2
      RETURNING id, username, email, gender, age, bio, location, profile_pic, followers, following, profile, level, own_groups_count
    `;
    const updateValues = [[normalizedCurrentUser], targetUser];

    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      console.error(`Add-friend: Update query returned no rows for username=${targetUser}, follower=${normalizedCurrentUser}`);
      return res.status(500).json({ message: 'Failed to update followers' });
    }

    res.status(200).json({
      message: 'Successfully followed user',
      user: updateResult.rows[0]
    });
  } catch (error) {
    console.error(`Add-friend error for username=${username}, currentUser=${currentUser}: ${error.message}`, error.stack);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Remove current user from another user's followers array
router.post('/unfriend', async (req, res) => {
  const { currentUser, username } = req.body;

  try {
    // Validate input
    if (!username || typeof username !== 'string' || username.trim() === '') {
      return res.status(400).json({ message: 'Invalid target username provided' });
    }
    if (!currentUser || typeof currentUser !== 'string' || currentUser.trim() === '') {
      return res.status(400).json({ message: 'Invalid current user provided' });
    }

    // Normalize usernames
    const normalizedUsername = username.trim();
    const normalizedCurrentUser = currentUser.trim();

    // Check if target user exists
    const checkQuery = `SELECT username, followers FROM users WHERE LOWER(username) = LOWER($1)`;
    const checkResult = await pool.query(checkQuery, [normalizedUsername]);

    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Target user not found' });
    }

    const targetUser = checkResult.rows[0].username;
    const { followers } = checkResult.rows[0];

    // Check if current user exists
    const currentUserCheckQuery = `SELECT username FROM users WHERE LOWER(username) = LOWER($1)`;
    const currentUserCheckResult = await pool.query(currentUserCheckQuery, [normalizedCurrentUser]);

    if (currentUserCheckResult.rows.length === 0) {
      return res.status(404).json({ message: 'Current user not found' });
    }

    // Check if not following
    if (!followers || !followers.includes(normalizedCurrentUser)) {
      return res.status(400).json({ message: 'Not following this user' });
    }

    // Remove current user from followers array
    const updateQuery = `
      UPDATE users 
      SET 
        followers = array_remove(followers, $1)
      WHERE username = $2
      RETURNING id, username, email, gender, age, bio, location, profile_pic, followers, following, profile, level, own_groups_count
    `;
    const updateValues = [normalizedCurrentUser, targetUser];

    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      console.error(`Unfriend: Update query returned no rows for username=${targetUser}, follower=${normalizedCurrentUser}`);
      return res.status(500).json({ message: 'Failed to unfollow user' });
    }

    res.status(200).json({
      message: 'Successfully unfollowed user',
      user: updateResult.rows[0]
    });
  } catch (error) {
    console.error(`Unfriend error for username=${username}, currentUser=${currentUser}: ${error.message}`, error.stack);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Block a user and update followers/following arrays
router.post('/block-user', async (req, res) => {
  const { currentUser, username } = req.body;

  try {
    // Validate input
    if (!username || typeof username !== 'string' || username.trim() === '') {
      return res.status(400).json({ message: 'Invalid target username provided' });
    }
    if (!currentUser || typeof currentUser !== 'string' || currentUser.trim() === '') {
      return res.status(400).json({ message: 'Invalid current user provided' });
    }

    // Normalize usernames
    const normalizedUsername = username.trim();
    const normalizedCurrentUser = currentUser.trim();

    // Check if target user exists
    const targetUserCheckQuery = `SELECT username, followers, following FROM users WHERE LOWER(username) = LOWER($1)`;
    const targetUserCheckResult = await pool.query(targetUserCheckQuery, [normalizedUsername]);

    if (targetUserCheckResult.rows.length === 0) {
      return res.status(404).json({ message: 'Target user not found' });
    }

    const targetUser = targetUserCheckResult.rows[0].username;

    // Check if current user exists
    const currentUserCheckQuery = `SELECT username, blocklist, followers, following FROM users WHERE LOWER(username) = LOWER($1)`;
    const currentUserCheckResult = await pool.query(currentUserCheckQuery, [normalizedCurrentUser]);

    if (currentUserCheckResult.rows.length === 0) {
      return res.status(404).json({ message: 'Current user not found' });
    }

    const currentUserData = currentUserCheckResult.rows[0];

    // Prevent self-blocking
    if (targetUser.toLowerCase() === normalizedCurrentUser.toLowerCase()) {
      return res.status(400).json({ message: 'Cannot block yourself' });
    }

    // Check if already blocked
    if (currentUserData.blocklist && currentUserData.blocklist.includes(normalizedUsername)) {
      return res.status(400).json({ message: 'User already blocked' });
    }

    // Start transaction
    await pool.query('BEGIN');

    try {
      // 1. Add target user to current user's blocklist
      const updateBlocklistQuery = `
        UPDATE users 
        SET 
          blocklist = COALESCE(blocklist, '{}') || $1
        WHERE username = $2
        RETURNING blocklist
      `;
      const blocklistValues = [[normalizedUsername], normalizedCurrentUser];
      const blocklistResult = await pool.query(updateBlocklistQuery, blocklistValues);
      if (blocklistResult.rows.length === 0) {
        throw new Error('Failed to update blocklist');
      }

      // 2. Remove target user from current user's followers
      const removeTargetFromCurrentFollowersQuery = `
        UPDATE users 
        SET 
          followers = array_remove(followers, $1)
        WHERE username = $2
      `;
      await pool.query(removeTargetFromCurrentFollowersQuery, [normalizedUsername, normalizedCurrentUser]);

      // 3. Remove current user from target user's followers
      const removeCurrentFromTargetFollowersQuery = `
        UPDATE users 
        SET 
          followers = array_remove(followers, $1)
        WHERE username = $2
      `;
      await pool.query(removeCurrentFromTargetFollowersQuery, [normalizedCurrentUser, targetUser]);

      // 4. Remove target user from current user's following
      const removeTargetFromCurrentFollowingQuery = `
        UPDATE users 
        SET 
          following = array_remove(following, $1)
        WHERE username = $2
      `;
      await pool.query(removeTargetFromCurrentFollowingQuery, [normalizedUsername, normalizedCurrentUser]);

      // 5. Remove current user from target user's following
      const removeCurrentFromTargetFollowingQuery = `
        UPDATE users 
        SET 
          following = array_remove(following, $1)
        WHERE username = $2
      `;
      await pool.query(removeCurrentFromTargetFollowingQuery, [normalizedCurrentUser, targetUser]);

      // Fetch updated current user data
      const fetchUpdatedUserQuery = `
        SELECT id, username, email, gender, age, bio, location, profile_pic, followers, following, blocklist, profile, level, own_groups_count
        FROM users 
        WHERE username = $1
      `;
      const updatedUserResult = await pool.query(fetchUpdatedUserQuery, [normalizedCurrentUser]);

      if (updatedUserResult.rows.length === 0) {
        throw new Error('Failed to fetch updated user data');
      }

      // Commit transaction
      await pool.query('COMMIT');

      res.status(200).json({
        message: 'Successfully blocked user',
        user: updatedUserResult.rows[0]
      });
    } catch (error) {
      await pool.query('ROLLBACK');
      console.error(`Block-user transaction error for username=${username}, currentUser=${currentUser}: ${error.message}`, error.stack);
      throw error;
    }
  } catch (error) {
    console.error(`Block-user error for username=${username}, currentUser=${currentUser}: ${error.message}`, error.stack);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get current user's blocklist
router.get('/get-blocklist/:username', async (req, res) => {
  const { username } = req.params;

  try {
    // Validate input
    if (!username || typeof username !== 'string' || username.trim() === '') {
      return res.status(400).json({ message: 'Invalid username provided' });
    }

    // Normalize username
    const normalizedUsername = username.trim();

    // Fetch blocklist
    const query = `
      SELECT blocklist
      FROM users 
      WHERE LOWER(username) = LOWER($1)
    `;
    const result = await pool.query(query, [normalizedUsername]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    const blocklist = result.rows[0].blocklist || [];
    res.status(200).json({
      message: 'Blocklist retrieved successfully',
      blocklist
    });
  } catch (error) {
    console.error(`Get-blocklist error for username=${username}: ${error.message}`, error.stack);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Unblock a user
router.post('/unblock-user', async (req, res) => {
  const { currentUser, username } = req.body;

  try {
    // Validate input
    if (!username || typeof username !== 'string' || username.trim() === '') {
      return res.status(400).json({ message: 'Invalid target username provided' });
    }
    if (!currentUser || typeof currentUser !== 'string' || currentUser.trim() === '') {
      return res.status(400).json({ message: 'Invalid current user provided' });
    }

    // Normalize usernames
    const normalizedUsername = username.trim();
    const normalizedCurrentUser = currentUser.trim();

    // Check if target user exists
    const targetUserCheckQuery = `SELECT username FROM users WHERE LOWER(username) = LOWER($1)`;
    const targetUserCheckResult = await pool.query(targetUserCheckQuery, [normalizedUsername]);

    if (targetUserCheckResult.rows.length === 0) {
      return res.status(404).json({ message: 'Target user not found' });
    }

    const targetUser = targetUserCheckResult.rows[0].username;

    // Check if current user exists and get blocklist
    const currentUserCheckQuery = `SELECT username, blocklist FROM users WHERE LOWER(username) = LOWER($1)`;
    const currentUserCheckResult = await pool.query(currentUserCheckQuery, [normalizedCurrentUser]);

    if (currentUserCheckResult.rows.length === 0) {
      return res.status(404).json({ message: 'Current user not found' });
    }

    const currentUserData = currentUserCheckResult.rows[0];

    // Prevent self-unblocking
    if (targetUser.toLowerCase() === normalizedCurrentUser.toLowerCase()) {
      return res.status(400).json({ message: 'Cannot unblock yourself' });
    }

    // Check if user is not blocked
    if (!currentUserData.blocklist || !currentUserData.blocklist.includes(normalizedUsername)) {
      return res.status(400).json({ message: 'User is not blocked' });
    }

    // Remove target user from blocklist
    const updateQuery = `
      UPDATE users 
      SET 
        blocklist = array_remove(blocklist, $1)
      WHERE username = $2
      RETURNING id, username, email, gender, age, bio, location, profile_pic, followers, following, blocklist, profile, level, own_groups_count
    `;
    const updateValues = [normalizedUsername, normalizedCurrentUser];

    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      console.error(`Unblock-user: Update query returned no rows for username=${targetUser}, currentUser=${normalizedCurrentUser}`);
      return res.status(500).json({ message: 'Failed to unblock user' });
    }

    res.status(200).json({
      message: 'Successfully unblocked user',
      user: updateResult.rows[0]
    });
  } catch (error) {
    console.error(`Unblock-user error for username=${username}, currentUser=${currentUser}: ${error.message}`, error.stack);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;