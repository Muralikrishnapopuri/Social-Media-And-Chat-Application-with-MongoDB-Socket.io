// users.js
const express = require('express');
const pool = require('../config/db');
const authMiddleware = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Ensure this folder exists
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});
const upload = multer({ storage });

// Update user data (password, age, location, gender, bio, profile_pic)
router.put('/update', authMiddleware, upload.single('profile_pic'), async (req, res) => {
  const { username } = req.user; // Extracted from authMiddleware
  const { password, age, location, gender, bio } = req.body;
  const profile_pic = req.file ? `/uploads/${req.file.filename}` : null;

  try {
    // Check if the user exists
    const checkQuery = `SELECT * FROM users WHERE username = $1`;
    const checkResult = await pool.query(checkQuery, [username]);
    
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Prepare the update query for specified fields
    const updateQuery = `
      UPDATE users 
      SET 
        password = COALESCE($1, password),
        age = COALESCE($2, age),
        location = COALESCE($3, location),
        gender = COALESCE($4, gender),
        bio = COALESCE($5, bio),
        profile_pic = COALESCE($6, profile_pic)
      WHERE username = $7
      RETURNING id, username, email, password, gender, age, bio, location, profile_pic, followers, following, profile, level, own_groups_count
    `;
    
    const updateValues = [
      password || null,
      age || null,
      location || null,
      gender || null,
      bio || null,
      profile_pic || null,
      username
    ];

    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to update user data' });
    }

    res.status(200).json({
      message: 'User data updated successfully',
      user: updateResult.rows[0]
    });
  } catch (error) {
    console.error('User update error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get current user profile (verify id and username)
router.get('/profile', authMiddleware, async (req, res) => {
  const { id, username } = req.user; // Extracted from authMiddleware

  try {
    let profileQuery;
    let profileValues;

    if (id && username) {
      profileQuery = `
        SELECT id, username, email, password, gender, age, bio, location, profile_pic, 
               followers, following, profile, level, own_groups_count 
        FROM users 
        WHERE id = $1 AND username = $2
      `;
      profileValues = [id, username];
    } else if (username) {
      profileQuery = `
        SELECT id, username, email, password, gender, age, bio, location, profile_pic, 
               followers, following, profile, level, own_groups_count 
        FROM users 
        WHERE username = $1
      `;
      profileValues = [username];
    } else {
      return res.status(400).json({ 
        message: 'Invalid authentication data: username is required' 
      });
    }

    const profileResult = await pool.query(profileQuery, profileValues);

    if (profileResult.rows.length === 0) {
      return res.status(404).json({ 
        message: id 
          ? 'Profile not found or verification failed: ID and username do not match' 
          : 'Profile not found for the given username'
      });
    }

    res.status(200).json({
      message: 'Profile retrieved successfully',
      user: profileResult.rows[0]
    });
  } catch (error) {
    console.error('Profile retrieval error:', error.message);
    res.status(500).json({ message: 'Server error: Unable to retrieve profile' });
  }
});

// New route to delete profile picture
router.delete('/profile-pic', authMiddleware, async (req, res) => {
  const { username } = req.user;

  try {
    // Check if the user exists
    const checkQuery = `SELECT profile_pic FROM users WHERE username = $1`;
    const checkResult = await pool.query(checkQuery, [username]);

    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Update the profile_pic to null
    const deleteQuery = `
      UPDATE users 
      SET profile_pic = NULL 
      WHERE username = $1
      RETURNING id, username, email, password, gender, age, bio, location, profile_pic, followers, following, profile, level, own_groups_count
    `;
    const deleteResult = await pool.query(deleteQuery, [username]);

    if (deleteResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to delete profile picture' });
    }

    res.status(200).json({
      message: 'Profile picture deleted successfully',
      user: deleteResult.rows[0]
    });
  } catch (error) {
    console.error('Profile picture deletion error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// New route to view profile by username
router.get('/profile/:username', async (req, res) => {
  const { username } = req.params;

  try {
    const profileQuery = `
      SELECT id, username, email, gender, age, bio, location, profile_pic, 
             followers, following, profile, level, own_groups_count 
      FROM users 
      WHERE username = $1
    `;
    const profileValues = [username];

    const profileResult = await pool.query(profileQuery, profileValues);

    if (profileResult.rows.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json({
      message: 'Profile retrieved successfully',
      user: profileResult.rows[0]
    });
  } catch (error) {
    console.error('Profile retrieval error:', error.message);
    res.status(500).json({ message: 'Server error: Unable to retrieve profile' });
  }
});

module.exports = router;