const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');
const router = express.Router();

// Register Route
router.post('/register', async (req, res) => {
    const { username, email, password, gender } = req.body;
  
    if (!username || !email || !password || !gender) {
      return res.status(400).json({ message: 'All fields are required' });
    }
  
    try {
      // Check if username or email already exists
      const checkQuery = `
        SELECT * FROM users 
        WHERE username = $1 OR email = $2
      `;
      const checkResult = await pool.query(checkQuery, [username, email]);
      if (checkResult.rows.length > 0) {
        return res.status(400).json({ message: 'Username or email already exists' });
      }
  
      // Hash password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
  
      // Insert user (without specifying level, letting default handle it)
      const insertQuery = `
        INSERT INTO users (username, email, password, gender)
        VALUES ($1, $2, $3, $4)
        RETURNING id, username, email, gender${pool.options.connectionString.includes('level') ? ', level' : ''}
      `;
      const insertResult = await pool.query(insertQuery, [username, email, hashedPassword, gender]);
      const user = insertResult.rows[0];
  
      // Generate JWT
      const payload = { id: user.id, username: user.username };
      const token = jwt.sign(payload, process.env.JWT_SECRET || 'your-default-secret', { expiresIn: '1h' });
  
      // Send complete response
      res.status(201).json({
        success: true,
        message: 'Registration successful',
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          gender: user.gender,
          ...(user.level && { level: user.level })
        }
      });
    } catch (error) {
      console.error('Registration error:', error.message);
      res.status(500).json({ 
        success: false,
        message: 'Server error',
        error: error.message 
      });
    }
});

// Login Route
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ 
      success: false,
      message: 'Username and password are required' 
    });
  }

  try {
    const selectQuery = `
      SELECT id, username, email, password, gender${pool.options.connectionString.includes('level') ? ', level' : ''} 
      FROM users 
      WHERE username = $1
    `;
    const selectResult = await pool.query(selectQuery, [username]);
    const user = selectResult.rows[0];

    if (!user) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid username or password' 
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ 
        success: false,
        message: 'Invalid username or password' 
      });
    }

    const payload = { id: user.id, username: user.username };
    const token = jwt.sign(
      payload,
      process.env.JWT_SECRET || 'your-default-secret',
      { expiresIn: '1h' }
    );

    // Send complete response
    res.status(200).json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        gender: user.gender,
        ...(user.level && { level: user.level })
      }
    });
  } catch (error) {
    console.error('Login error:', error.message);
    res.status(500).json({ 
      success: false,
      message: 'Server error',
      error: error.message 
    });
  }
});

// Verify Token Route
router.post('/verify-token', async (req, res) => {
  const authHeader = req.header('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ 
      success: false,
      message: 'No token provided' 
    });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-default-secret');
    const selectQuery = `
      SELECT id, username, email, gender${pool.options.connectionString.includes('level') ? ', level' : ''} 
      FROM users 
      WHERE username = $1
    `;
    const selectResult = await pool.query(selectQuery, [decoded.username]);
    const user = selectResult.rows[0];

    if (!user) {
      return res.status(404).json({ 
        success: false,
        message: 'User not found' 
      });
    }

    // Refresh the token
    const newToken = jwt.sign(
      { id: user.id, username: user.username },
      process.env.JWT_SECRET || 'your-default-secret',
      { expiresIn: '1h' }
    );

    // Send complete response
    res.status(200).json({
      success: true,
      message: 'Token is valid',
      token: newToken,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        gender: user.gender,
        ...(user.level && { level: user.level })
      }
    });
  } catch (error) {
    console.error('Token verification error:', error.message);
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ 
        success: false,
        message: 'Token has expired' 
      });
    } else if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ 
        success: false,
        message: 'Token is not valid' 
      });
    }
    res.status(500).json({ 
      success: false,
      message: 'Server error',
      error: error.message 
    });
  }
});

module.exports = router;