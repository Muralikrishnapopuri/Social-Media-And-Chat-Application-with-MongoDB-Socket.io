const express = require('express');
const sharp = require('sharp');
const pool = require('../config/db');
const authMiddleware = require('../middleware/auth');
const fs = require('fs').promises;
const router = express.Router();

const BASE_URL = process.env.BASE_URL || 'http://localhost:5000';

// Helper function to compress and return server URL
const compressImage = async (file) => {
  if (!file) return '';

  const ext = file.originalname.split('.').pop().toLowerCase();
  const formatMap = {
    jfif: 'jpeg',
    jpg: 'jpeg',
    jpe: 'jpeg',
    tif: 'tiff',
  };
  const sharpFormat = formatMap[ext] || ext;

  const supportedFormats = [
    'heic', 'heif', 'avif', 'jpeg', 'jpg', 'jpe', 'tile', 'dz',
    'png', 'raw', 'tiff', 'tif', 'webp', 'gif', 'jp2', 'jpx',
    'j2k', 'j2c', 'jxl'
  ];

  const outputFormat = supportedFormats.includes(sharpFormat) ? sharpFormat : 'jpeg';
  const tempPath = `${file.path}.tmp`;

  try {
    await sharp(file.path)
      .resize(200, 200, { fit: 'cover' })
      .toFormat(outputFormat, { quality: 80 })
      .toFile(tempPath);

    await fs.rename(tempPath, file.path);
    return `${BASE_URL}/Uploads/${file.filename}`;
  } catch (error) {
    console.error('Image compression error:', error.message);
    try {
      await fs.unlink(tempPath);
    } catch (unlinkError) {
      console.error('Failed to clean up temp file:', unlinkError.message);
    }
    throw new Error('Failed to process image due to a server issue');
  }
};

// Get all groups
router.get('/', async (req, res) => {
  try {
    const query = `SELECT * FROM groups`;
    const result = await pool.query(query);
    res.status(200).json(result.rows);
  } catch (error) {
    console.error('Error fetching groups:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get a specific group by ID
router.get('/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;

  try {
    const query = `SELECT * FROM groups WHERE group_id = $1`;
    const result = await pool.query(query, [group_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const group = result.rows[0];
    res.status(200).json({ group });
  } catch (error) {
    console.error('Error fetching group by ID:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create a group
router.post('/create', authMiddleware, async (req, res) => {
  const { group_title, description, owner } = req.body;
  let group_pic_url = '';

  if (!group_title || !owner) {
    return res.status(400).json({ message: 'Group title and owner are required' });
  }

  try {
    // Check if group title already exists
    const checkQuery = `SELECT * FROM groups WHERE group_title = $1`;
    const checkResult = await pool.query(checkQuery, [group_title]);
    if (checkResult.rows.length > 0) {
      return res.status(400).json({ message: 'Group title already exists' });
    }

    // Get current user's level and own_groups_count
    const userQuery = `SELECT level, own_groups_count FROM users WHERE username = $1`;
    const userResult = await pool.query(userQuery, [owner]);
    if (userResult.rows.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }
    const { level, own_groups_count } = userResult.rows[0];

    // Fetch the corresponding level row from levels table
    const levelQuery = `SELECT * FROM levels WHERE level = $1`;
    const levelResult = await pool.query(levelQuery, [level]);
    if (levelResult.rows.length === 0) {
      return res.status(500).json({ message: 'Level configuration not found' });
    }
    const levelRow = levelResult.rows[0];

    // Check if own_groups_count is less than the limit in levelRow
    if (own_groups_count >= levelRow.own_groups_count) {
      return res.status(403).json({ message: 'Upgrade your account to create more groups' });
    }

    // Compress image if uploaded
    if (req.file) {
      group_pic_url = await compressImage(req.file);
    }

    // Insert new group
    const insertQuery = `
      INSERT INTO groups (group_title, group_pic, description, total_users, blocklist, users_array, owner, admins)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;
    const insertValues = [
      group_title,
      group_pic_url,
      description || '',
      1,
      [],
      [owner],
      owner,
      [owner]
    ];
    const insertResult = await pool.query(insertQuery, insertValues);
    const newGroup = insertResult.rows[0];

    // Increment user's own_groups_count
    const updateUserQuery = `
      UPDATE users 
      SET own_groups_count = own_groups_count + 1 
      WHERE username = $1
    `;
    await pool.query(updateUserQuery, [owner]);

    res.status(201).json({
      message: 'Group created successfully',
      group: newGroup
    });
  } catch (error) {
    console.error('Group creation error:', error.message);
    res.status(500).json({ 
      message: error.message === 'Failed to process image due to a server issue' 
        ? 'Failed to process uploaded image. Please try again or use a different format.'
        : 'Server error'
    });
  }
});

// Edit a group
router.put('/edit/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;
  const { username } = req.user;
  const { group_title, description, owner } = req.body;

  try {
    const checkQuery = `SELECT * FROM groups WHERE group_id = $1`;
    const checkResult = await pool.query(checkQuery, [group_id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Group not found' });
    } 

    const group = checkResult.rows[0];
    const isOwner = group.owner === username;
    const isAdmin = group.admins.includes(username);
    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: 'You are not authorized to edit this group' });
    }

    if (owner && owner !== username) {
      return res.status(403).json({ message: 'You cannot edit the owner field or impersonate another user' });
    }

    if (group_title && group_title !== group.group_title) {
      const titleCheckQuery = `SELECT * FROM groups WHERE group_title = $1 AND group_id != $2`;
      const titleCheckResult = await pool.query(titleCheckQuery, [group_title, group_id]);
      if (titleCheckResult.rows.length > 0) {
        return res.status(400).json({ message: 'Group title already exists' });
      }
    }

    const group_pic_url = req.file ? await compressImage(req.file) : group.group_pic;

    const updateQuery = `
      UPDATE groups 
      SET 
        group_title = $1,
        group_pic = $2,
        description = $3
      WHERE group_id = $4
      RETURNING *
    `;
    const updateValues = [
      group_title || group.group_title,
      group_pic_url,
      description !== undefined ? description : group.description,
      group_id
    ];
    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to update group' });
    }

    res.status(200).json({
      message: 'Group updated successfully',
      group: updateResult.rows[0]
    });
  } catch (error) {
    console.error('Group update error:', error.message);
    res.status(500).json({ 
      message: error.message === 'Failed to process image due to a server issue' 
        ? 'Failed to process uploaded image. Please try again or use a different format.'
        : 'Server error'
    });
  }
});

// Delete a group
router.delete('/delete/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;
  const { username } = req.user;

  try {
    const checkQuery = `SELECT * FROM groups WHERE group_id = $1 AND owner = $2`;
    const checkResult = await pool.query(checkQuery, [group_id, username]);

    if (checkResult.rows.length === 0) {
      return res.status(403).json({ 
        message: 'Group not found or you are not authorized to delete it' 
      });
    }

    const deleteQuery = `DELETE FROM groups WHERE group_id = $1 RETURNING *`;
    const deleteResult = await pool.query(deleteQuery, [group_id]);

    if (deleteResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to delete group' });
    }

    // Decrement user's own_groups_count
    const updateUserQuery = `
      UPDATE users 
      SET own_groups_count = own_groups_count - 1 
      WHERE username = $1
    `;
    await pool.query(updateUserQuery, [username]);

    res.status(200).json({
      message: 'Group deleted successfully',
      group: deleteResult.rows[0]
    });
  } catch (error) {
    console.error('Group deletion error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Join a group
router.post('/join/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;
  const { username } = req.user;

  try {
    const checkQuery = `SELECT * FROM groups WHERE group_id = $1`;
    const checkResult = await pool.query(checkQuery, [group_id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const group = checkResult.rows[0];

    if (group.blocklist.includes(username)) {
      return res.status(403).json({ message: 'You are blocked from joining this group' });
    }

    if (group.users_array.includes(username)) {
      return res.status(204).send();
    }

    const updatedUsersArray = [...group.users_array, username];
    const updatedTotalUsers = group.total_users + 1;

    const updateQuery = `
      UPDATE groups 
      SET 
        users_array = $1,
        total_users = $2
      WHERE group_id = $3
      RETURNING *
    `;
    const updateValues = [updatedUsersArray, updatedTotalUsers, group_id];
    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to join group' });
    }

    res.status(200).json({
      message: 'Successfully joined group',
      group: updateResult.rows[0]
    });
  } catch (error) {
    console.error('Group join error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Leave a group
router.post('/leave/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;
  const { username } = req.user;

  try {
    const checkQuery = `SELECT * FROM groups WHERE group_id = $1`;
    const checkResult = await pool.query(checkQuery, [group_id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const group = checkResult.rows[0];

    if (group.owner === username) {
      return res.status(403).json({ message: 'Owner cannot leave the group. Delete it instead.' });
    }

    if (!group.users_array.includes(username)) {
      return res.status(400).json({ message: 'You are not a member of this group' });
    }

    const updatedUsersArray = group.users_array.filter(user => user !== username);
    const updatedTotalUsers = group.total_users - 1;

    const updateQuery = `
      UPDATE groups 
      SET 
        users_array = $1,
        total_users = $2
      WHERE group_id = $3
      RETURNING *
    `;
    const updateValues = [updatedUsersArray, updatedTotalUsers, group_id];
    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to leave group' });
    }

    res.status(200).json({
      message: 'Successfully left the group',
      group: updateResult.rows[0]
    });
  } catch (error) {
    console.error('Group leave error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get user profiles
router.post('/user-profiles', authMiddleware, async (req, res) => {
  const { user_list } = req.body;

  if (!Array.isArray(user_list) || user_list.length === 0) {
    return res.status(400).json({ message: 'user_list must be a non-empty array' });
  }

  try {
    const query = `
      SELECT username, profile_pic, age, gender 
      FROM users 
      WHERE username = ANY($1)
    `;
    const result = await pool.query(query, [user_list]);

    res.status(200).json({
      users: result.rows
    });
  } catch (error) {
    console.error('Error fetching user profiles:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Make a user an admin
router.post('/make-admin/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;
  const { username: targetUsername } = req.body;
  const { username: currentUsername } = req.user;

  if (!targetUsername) {
    return res.status(400).json({ message: 'Username to make admin is required' });
  }

  try {
    const checkQuery = `SELECT * FROM groups WHERE group_id = $1`;
    const checkResult = await pool.query(checkQuery, [group_id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const group = checkResult.rows[0];

    const isOwner = group.owner === currentUsername;
    const isAdmin = group.admins.includes(currentUsername);
    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: 'You are not authorized to make admins' });
    }

    if (!group.users_array.includes(targetUsername)) {
      return res.status(400).json({ message: 'User is not a member of this group' });
    }

    if (group.admins.includes(targetUsername)) {
      return res.status(400).json({ message: 'User is already an admin' });
    }

    const updatedAdmins = [...group.admins, targetUsername];

    const updateQuery = `
      UPDATE groups 
      SET 
        admins = $1
      WHERE group_id = $2
      RETURNING *
    `;
    const updateValues = [updatedAdmins, group_id];
    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to update admin list' });
    }

    res.status(200).json({
      message: `${targetUsername} has been made an admin`,
      group: updateResult.rows[0]
    });
  } catch (error) {
    console.error('Make admin error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Remove a user as admin
router.post('/remove-admin/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;
  const { username: targetUsername } = req.body;
  const { username: currentUsername } = req.user;

  if (!targetUsername) {
    return res.status(400).json({ message: 'Username to remove as admin is required' });
  }

  try {
    const checkQuery = `SELECT * FROM groups WHERE group_id = $1`;
    const checkResult = await pool.query(checkQuery, [group_id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const group = checkResult.rows[0];

    const isOwner = group.owner === currentUsername;
    const isAdmin = group.admins.includes(currentUsername);
    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: 'You are not authorized to remove admins' });
    }

    if (group.owner === targetUsername) {
      return res.status(400).json({ message: 'Owner cannot be removed as admin' });
    }

    if (!group.admins.includes(targetUsername)) {
      return res.status(400).json({ message: 'User is not an admin' });
    }

    const updatedAdmins = group.admins.filter(admin => admin !== targetUsername);

    const updateQuery = `
      UPDATE groups 
      SET 
        admins = $1
      WHERE group_id = $2
      RETURNING *
    `;
    const updateValues = [updatedAdmins, group_id];
    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to update admin list' });
    }

    res.status(200).json({
      message: `${targetUsername} has been removed as an admin`,
      group: updateResult.rows[0]
    });
  } catch (error) {
    console.error('Remove admin error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Remove a user from the group
router.post('/remove-user/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;
  const { username: targetUsername } = req.body;
  const { username: currentUsername } = req.user;

  if (!targetUsername) {
    return res.status(400).json({ message: 'Username to remove is required' });
  }

  try {
    const checkQuery = `SELECT * FROM groups WHERE group_id = $1`;
    const checkResult = await pool.query(checkQuery, [group_id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const group = checkResult.rows[0];

    const isOwner = group.owner === currentUsername;
    const isAdmin = group.admins.includes(currentUsername);
    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: 'You are not authorized to remove users' });
    }

    if (group.owner === targetUsername) {
      return res.status(400).json({ message: 'Owner cannot be removed from the group' });
    }

    if (!group.users_array.includes(targetUsername)) {
      return res.status(400).json({ message: 'User is not a member of this group' });
    }

    const updatedUsersArray = group.users_array.filter(user => user !== targetUsername);
    const updatedTotalUsers = group.total_users - 1;
    const updatedAdmins = group.admins.filter(admin => admin !== targetUsername);

    const updateQuery = `
      UPDATE groups 
      SET 
        users_array = $1,
        total_users = $2,
        admins = $3
      WHERE group_id = $4
      RETURNING *
    `;
    const updateValues = [updatedUsersArray, updatedTotalUsers, updatedAdmins, group_id];
    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to remove user' });
    }

    res.status(200).json({
      message: `${targetUsername} has been removed from the group`,
      group: updateResult.rows[0]
    });
  } catch (error) {
    console.error('Remove user error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Ban a user from the group
router.post('/ban-user/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;
  const { username: targetUsername } = req.body;
  const { username: currentUsername } = req.user;

  if (!targetUsername) {
    return res.status(400).json({ message: 'Username to ban is required' });
  }

  try {
    const checkQuery = `SELECT * FROM groups WHERE group_id = $1`;
    const checkResult = await pool.query(checkQuery, [group_id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const group = checkResult.rows[0];

    const isOwner = group.owner === currentUsername;
    const isAdmin = group.admins.includes(currentUsername);
    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: 'You are not authorized to ban users' });
    }

    if (group.owner === targetUsername) {
      return res.status(400).json({ message: 'Owner cannot be banned' });
    }

    if (group.blocklist.includes(targetUsername)) {
      return res.status(400).json({ message: 'User is already banned' });
    }

    // Remove user from admins (if applicable) and add to blocklist
    const updatedAdmins = group.admins.filter(admin => admin !== targetUsername);
    const updatedBlocklist = [...group.blocklist, targetUsername];

    const updateQuery = `
      UPDATE groups 
      SET 
        admins = $1,
        blocklist = $2
      WHERE group_id = $3
      RETURNING *
    `;
    const updateValues = [
      updatedAdmins,
      updatedBlocklist,
      group_id
    ];
    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to ban user' });
    }

    res.status(200).json({
      message: `${targetUsername} has been banned from the group`,
      group: updateResult.rows[0]
    });
  } catch (error) {
    console.error('Ban user error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Approve (unban) a user
router.post('/approve-user/:group_id', authMiddleware, async (req, res) => {
  const { group_id } = req.params;
  const { username: targetUsername } = req.body;
  const { username: currentUsername } = req.user;

  if (!targetUsername) {
    return res.status(400).json({ message: 'Username to approve is required' });
  }

  try {
    const checkQuery = `SELECT * FROM groups WHERE group_id = $1`;
    const checkResult = await pool.query(checkQuery, [group_id]);
    if (checkResult.rows.length === 0) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const group = checkResult.rows[0];

    const isOwner = group.owner === currentUsername;
    const isAdmin = group.admins.includes(currentUsername);
    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: 'You are not authorized to approve users' });
    }

    if (!group.blocklist.includes(targetUsername)) {
      return res.status(400).json({ message: 'User is not banned' });
    }

    const updatedBlocklist = group.blocklist.filter(user => user !== targetUsername);

    const updateQuery = `
      UPDATE groups 
      SET 
        blocklist = $1
      WHERE group_id = $2
      RETURNING *
    `;
    const updateValues = [updatedBlocklist, group_id];
    const updateResult = await pool.query(updateQuery, updateValues);

    if (updateResult.rows.length === 0) {
      return res.status(500).json({ message: 'Failed to approve user' });
    }

    res.status(200).json({
      message: `${targetUsername} has been approved and can now join the group`,
      group: updateResult.rows[0]
    });
  } catch (error) {
    console.error('Approve user error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;